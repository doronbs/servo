//
// All comand and response from C1 to CM and CM to C1
//
// C1 commands
#define boot_status_cm 1
#define start_udp 2
#define start_udp_2 3
#define send_load_line 4
#define send_last_load_line 5


//
// CM response
//

#define cm_status_init 1
#define boot_response_fail 20
#define boot_response_init 3
#define boot_response_udp_ready 4
#define boot_response_udp_not_ready 5
#define cm_start_udp 6
#define c1_get_status 7
#define c1_run 6
#define send_load_line_cmd_fail 9
#define send_program_load_cmd 10
#define send_no_program 11
#define send_run_cmd 12
#define send_no_run_cmd 12







#ifdef cm_cmd

const uint32_t boot_status_cm_cmd = boot_status_cm;
const uint32_t start_udp_cmd = start_udp;
const uint32_t start_udp_cmd_2 = start_udp_2;
const uint32_t send_load_line_cmd = send_load_line;
const uint32_t send_last_load_line_cmd = send_last_load_line;

const uint32_t cm_status_init_cmd = cm_status_init;
const uint32_t boot_response_fail_cmd = boot_response_fail;
const uint32_t boot_respone_init_cmd = boot_response_init;
const uint32_t boot_response_udp_not_ready_cmd = boot_response_udp_not_ready;
const uint32_t boot_response_udp_ready_cmd = boot_response_udp_ready;
const uint32_t cm_start_udp_cmd = cm_start_udp;
const uint32_t send_load_line_cmd_fail_cmd =  send_load_line_cmd_fail;
const uint32_t boot_response_udp_not_ready_cmd;
const uint32_t c1_get_status_cmd =  send_load_line_cmd_fail;
const uint32_t c1_run_cmd = c1_run;
#define  s_boot_status_cmd 1
#define s_boot_response_init_cmd 2
#define s_start_Loader_cm_cmd 3
#define s_send_load_line_cmd 4
#define s_boot_response_fail_cmd 5

#endif


