//#############################################################################
//
// FILE:   flashapi_ex1_programming.c
//
// TITLE:  Flash programming example
//
//! \addtogroup driver_example_list
//! <h1> Flash Programming with AutoECC, DataAndECC, DataOnly and EccOnly </h1>
//!
//! This example demonstrates how to program Flash using API's following options
//! 1. AutoEcc generation
//! 2. DataOnly and EccOnly
//! 3. DataAndECC
//!
//!
//! \b External \b Connections \n
//!  - None.
//!
//! \b Watch \b Variables \n
//!  - None.
//!
//
//#############################################################################
// $Copyright:
// Copyright (C) 2022 Texas Instruments Incorporated - http://www.ti.com
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"

//
// Include Flash API include file
//
#include "F021_F2838x_C28x.h"

// Include Flash API example header file
//
#include "flash_programming_f2838x_c28x.h"

//
// Defines
//

//
// Data Buffers used for program operation using the flash API program function
//
uint32   *Buffer32;

uint32_t  sector_start_address[14] = {0x80000, 0x82000, 0x84000, 0x86000, 0x88000, 0x90000, 0x98000,
                                      0xA0000, 0xA8000, 0xB0000, 0xB8000, 0xBA000, 0xBC000 ,0xBE000 };

uint32_t *sector_ptr;
// Prototype of the functions used in this example
//
//void Example_Error(Fapi_StatusType status);
//void Example_Done(void);
//void Example_CallFlashAPI(void);
//void FMSTAT_Fail(void);
//void ECC_Fail(void);
//void Example_EraseSector(void);

//void Example_ProgramUsingAutoECC(void);
//void Example_ProgramUsingDataOnlyECCOnly(void);
//void Example_ProgramUsingDataAndECC(void);

//
// Main
//
#pragma CODE_SECTION(flash_prog_init, ".TI.ramfunc");
void flash_prog_init()
{
    Fapi_StatusType  oReturnCheck;
 // wait-states when the system clock frequency is changed.
    //
    Flash_claimPumpSemaphore(FLASH_CPU1_WRAPPER);

    Flash_initModule(FLASH0CTRL_BASE, FLASH0ECC_BASE, 3);

    //
    // Flash API functions should not be executed from the same bank on which
    // erase/program operations are in progress.
    // Also, note that there should not be any access to the Flash bank on
    // which erase/program operations are in progress.  Hence below function
    // is mapped to RAM for execution.
    //
    oReturnCheck = Fapi_initializeAPI(F021_CPU0_BASE_ADDRESS,
                                      DEVICE_SYSCLK_FREQ/1000000U);

    if(oReturnCheck != Fapi_Status_Success)
        while(1);
    //
    // Release the pump access
    //


    oReturnCheck = Fapi_setActiveFlashBank(Fapi_FlashBank0);

    if(oReturnCheck != Fapi_Status_Success)
    {
        //
        // Check Flash API documentation for possible errors
        //
        while(1);
    }


/*
    for (i = 8 ; i <14 ; i++)
    {

        //
        // Erase the sector that could be  programmed in the above example
        // Erase Sector6
        //
        sector_ptr = sector_start_address[i];
        oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,
                                                         sector_ptr);

        //
        // Wait until FSM is done with erase sector operation
        //
        while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}

        if(oReturnCheck != Fapi_Status_Success)
        {
            //
            // Check Flash API documentation for possible errors
            //
            while(1);
        }
    }
*/
}
#pragma CODE_SECTION(flash_erase, ".TI.ramfunc");
void flash_erase()
{
    uint16 i = 0;
    Fapi_StatusType  oReturnCheck;

    for (i = 8 ; i <14 ; i++)
    {

        //
        // Erase the sector that could be  programmed in the above example
        // Erase Sector6
        //
        sector_ptr = sector_start_address[i];
        oReturnCheck = Fapi_issueAsyncCommandWithAddress(Fapi_EraseSector,
                                                         sector_ptr);

        //
        // Wait until FSM is done with erase sector operation
        //
        while (Fapi_checkFsmForReady() != Fapi_Status_FsmReady){}

        if(oReturnCheck != Fapi_Status_Success)
        {
            //
            // Check Flash API documentation for possible errors
            //
            while(1);
        }
    }
}


//*****************************************************************************
//  Example_ProgramUsingDataOnlyECCOnly
//
//  Example function to Program data in Flash using "DataOnly" option and ECC
//  using "EccOnly" option.
//  Flash API functions used in this function are executed from RAM in this
//  example.
//*****************************************************************************
#pragma CODE_SECTION(Program_hex2000_line_ecc, ".TI.ramfunc");

bool Program_hex2000_line_ecc( uint32_t flash_address , uint16_t* flash_data , uint16_t length)
{
    uint16 *buffer;
    uint32 u32Index = 0;
    uint16 i = 0, ECC_B = 0, ECC_LB = 0, ECC_HB = 0;
    uint64 *LData, *HData, dataLow, dataHigh;
    Fapi_StatusType  oReturnCheck;
    Fapi_FlashStatusType  oFlashStatus;
    Fapi_FlashStatusWordType  oFlashStatusWord;
    uint16 length_w,length_mod;

    //
    // Program data using "DataOnly" option and ECC using "EccOnly" option.
    //
    // When DataOnly option is used, Flash API will program only the data
    // portion in Flash at the address specified.
    //
    // When EccOnly option is used, Flash API will program only the ECC portion
    // in Flash ECC memory space (Flash main array address should be provided
    // for this function and not the corresponding ECC address).
    // Fapi_calculateEcc is used to calculate the corresponding ECC of the data.
    //
    // Note that data buffer (Buffer) is aligned on 64-bit boundary for verify
    // reasons.
    //
    // In this example, 0x100 bytes are programmed in Flash Sector6
    // along with the specified ECC.
    //
    //
    // find flash sector to burn
    //


        buffer = flash_data;
        Buffer32 = flash_data;
        //
        // add peesing 0xffff to end of buffer
        //
        //length_w = length / 4;
        //length_mod = length % 8;
       // i = 0;
        //while (length_mod != 0)
        //{
         //   buffer[length_w+ +i] = 0xffff;
         //   i++;
         //   length_mod -= 1;
        //}
        buffer = flash_data;

        for(i=0, u32Index = flash_address;
           (u32Index < (flash_address + length/2));
           i+= 8, u32Index+= 8)
        {
            //
            // Point LData to the lower 64 bit data
            // and   HData to the higher 64 bit data
            //
            LData = (uint64 *)(Buffer32 + i/2);
            HData = (uint64 *)(Buffer32 + i/2 + 2);

            //
            // Calculate ECC for lower 64 bit and higher 64 bit data
            //
            ECC_LB = Fapi_calculateEcc(u32Index,*LData);
            ECC_HB = Fapi_calculateEcc(u32Index+4,*HData);
            ECC_B = ((ECC_HB<<8) | ECC_LB);

            oReturnCheck = Fapi_issueProgrammingCommand((uint32 *)u32Index,buffer+i,
                                                     8, &ECC_B, 2, Fapi_DataAndEcc);

            //
            // Wait until the Flash program operation is over
            //
            while(Fapi_checkFsmForReady() == Fapi_Status_FsmBusy);

            if(oReturnCheck != Fapi_Status_Success)
            {
                //
                // Check Flash API documentation for possible errors
                //
                Example_Error(oReturnCheck);
            }

            //
            // Read FMSTAT register contents to know the status of FSM after
            // program command to see if there are any program operation related
            // errors
            //
            oFlashStatus = Fapi_getFsmStatus();
            if(oFlashStatus != 0)
            {
                //
                // Check FMSTAT and debug accordingly
                //
                FMSTAT_Fail();
            }

            Flash_enableECC(FLASH0ECC_BASE);

            //
            // Read back the programmed data to check if there are any ECC failures
            //
            dataLow = *(uint64 *)(u32Index);

            Flash_ErrorStatus errorStatusLow = Flash_getLowErrorStatus(FLASH0ECC_BASE);
            if((errorStatusLow != FLASH_NO_ERR) || (dataLow != *LData))
            {
                ECC_Fail();
            }

            dataHigh = *(uint64 *)(u32Index + 4);

            Flash_ErrorStatus errorStatusHigh = Flash_getHighErrorStatus(FLASH0ECC_BASE);
            if((errorStatusHigh != FLASH_NO_ERR) || (dataHigh != *HData))
            {
                ECC_Fail();
            }

            //
            // Verify the programmed values.  Check for any ECC errors.
            //
            oReturnCheck = Fapi_doVerify((uint32 *)u32Index,
                                         4, Buffer32+(i/2),
                                         &oFlashStatusWord);

            if(oReturnCheck != Fapi_Status_Success)
            {
                //
                // Check Flash API documentation for possible errors
                //
                Example_Error(oReturnCheck);
            }
        }



}

void Example_Error(Fapi_StatusType status)
{
    //
    //  Error code will be in the status parameter
    //
    __asm("    ESTOP0");
}

//******************************************************************************
//  For this example, once we are done just stop here
//******************************************************************************
void Example_Done(void)
{
    __asm("    ESTOP0");
}

//******************************************************************************
// For this example, just stop here if FMSTAT fail occurs
//******************************************************************************
void FMSTAT_Fail(void)
{
    __asm("    ESTOP0");
}

//******************************************************************************
// For this example, just stop here if ECC fail occurs
//******************************************************************************
void ECC_Fail(void)
{
    __asm("    ESTOP0");
}

//
// End of File
//
