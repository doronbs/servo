1. run python application udp_388d_client_send_hex_2_mon.py
2. choose the specific file in python programmer code by select 1 or 2 and press "burn"
3. power off and on the board and press "run" for run the application that in c1 internal flash