import os
import socket
import random
import sys
import time
import timeit
sys.path.insert(0,'D:\OneDrive\OneDrive - DR Utilight Corp ltd\python3\chatlib')

#SERVER_IP = "127.0.0.1"  # Our server will run on same computer as client
#ERVER_IP = "10.100.102.94"  # Our server will not run on same computer as client
#SERVER_IP = "169.254.174.99"  # Our server will not run on same computer as client
#SERVER_IP = "192.168.0.4"  # Our server will not run on same computer as client
SERVER_IP = "192.168.141.4"  # Our server will not run on same computer as client
#SERVER_PORT = 8821
SERVER_PORT = 28000
#MAX_MSG_SIZE = 1024                                                                                                                               trans_data
MAX_MSG_SIZE = 1088
CM_ACK = 4
CM_NACK = 5
PYTHON_READ_TO_LOAD = 6
buf_tx_start_msg = "Something to show UDP is working \n";
buf_tx_start_msg_count = 35;
  #define send_program_load_cmd 10
#define send_run_cmd 11
#define send_run_cmd 12
#define send_no_run_cmd 12

def main():
    cmd = input("type file option [1 or 2]  ") 
    if cmd =='1':
        hex_file = open('gpio_ex2_toggle2_l.hex', 'r')
    else :
        hex_file = open('gpio_ex2_toggle2_s.hex', 'r')
    burn_count = 0
    print("client is active")
    server_addr = (SERVER_IP , SERVER_PORT)
    my_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    #my_socket.bind(server_addr)
    my_socket.setblocking(False)
    my_socket.settimeout(1000000)
    print(my_socket.type)
    print("server ip = ",SERVER_IP ,  "port = " , SERVER_PORT  )
    response = "START"
    my_socket.sendto(response.encode(), server_addr)   # send line
    print(response)
    (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
    data = server_message.decode()
    print("server_SEND",server_message, data)
    response = "burn"
    my_socket.sendto(response.encode(), server_addr)   # send line
    print(response)
    (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
    data = server_message.decode()
    print("server_SEND",server_message, data)
    msg_count = 0
    equel = True
    while 1:
        cmd = input("type your command : burn or status or run  ") 
        if cmd != "burn":
           my_socket.sendto(cmd.encode(), server_addr)   # send line
           data = server_message.decode()
           print (data)
           if data[0] == 10: print  ("program_load")
           if data[0] == 11: print  ("no program_load")
           if data[0] == 12: print  ("RUN")
           if data[0] == 13: print  ("RUN FAIL")
        if burn_count == 0:
           burn_count = 1
           while cmd == "burn":
                response = hex_file.readline()
                if response == '':
                     hex_file.close 
                     break
                print("Client sent: " , response)
                data = CM_NACK
                while data == CM_NACK:
                    my_socket.sendto(response.encode(), server_addr)   # send line
                    (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
                    data = server_message.decode()
                    print("response =",data)
        else:
                print("please turn off power. you can't burn now")
if __name__ == '__main__':
    main()
