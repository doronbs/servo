
#include "C1_BSP_GeneralInclude.h"

BSP_GPIO_Info_S g_bsp_gpio_info;

BSP_Return_E BSP_GPIO_Init (void)
{
    GPIO_setControllerCore(BSP_GPIO_CHANNEL_0, GPIO_CORE_CPU1);
    GPIO_setPadConfig(BSP_GPIO_CHANNEL_0, GPIO_PIN_TYPE_STD);
    GPIO_setControllerCore(BSP_GPIO_CHANNEL_1, GPIO_CORE_CPU1);
    GPIO_setPadConfig(BSP_GPIO_CHANNEL_1, GPIO_PIN_TYPE_STD);
    GPIO_setControllerCore(BSP_GPIO_CHANNEL_2, GPIO_CORE_CPU1);
    GPIO_setPadConfig(BSP_GPIO_CHANNEL_2, GPIO_PIN_TYPE_STD);
    GPIO_setControllerCore(BSP_GPIO_CHANNEL_3, GPIO_CORE_CPU1);
    GPIO_setPadConfig(BSP_GPIO_CHANNEL_3, GPIO_PIN_TYPE_STD);
    GPIO_setControllerCore(BSP_GPIO_CHANNEL_4, GPIO_CORE_CPU1);
    GPIO_setPadConfig(BSP_GPIO_CHANNEL_4, GPIO_PIN_TYPE_STD);

    return (BSP_RETURN_SUCCESS);
}

BSP_Return_E BSP_GPIO_SetCallback (BSP_GPIO_Channel_E eChannel, g_CallbackFunc cbFunc, BSP_GPIO_IntType_E eIntType)
{
    /* set  input */
    BSP_GPIO_SetPInDirection(eChannel, BSP_GPIO_DIRECTION_INPUT);

    /* set interrupt */
    switch(eChannel)
    {
        case BSP_GPIO_CHANNEL_0:
            GPIO_setPadConfig(BSP_GPIO_CHANNEL_0, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
            g_bsp_gpio_info.cbFunc[0] = cbFunc;
            if(eIntType == BSP_GPIO_INT_TYPE_RISING_EDGE)
                GPIO_setInterruptType(GPIO_INT_XINT1, GPIO_INT_TYPE_RISING_EDGE);
            else
                GPIO_setInterruptType(GPIO_INT_XINT1, GPIO_INT_TYPE_FALLING_EDGE);
            GPIO_setInterruptPin(BSP_GPIO_CHANNEL_0, GPIO_INT_XINT1);
            GPIO_enableInterrupt(GPIO_INT_XINT1);
            Interrupt_register(INT_XINT1, &BSP_GPIO_ISR0);
            Interrupt_enable(INT_XINT1);
            break;
        case BSP_GPIO_CHANNEL_1:
            GPIO_setPadConfig(BSP_GPIO_CHANNEL_1, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
            g_bsp_gpio_info.cbFunc[1] = cbFunc;
            if(eIntType == BSP_GPIO_INT_TYPE_RISING_EDGE)
                GPIO_setInterruptType(GPIO_INT_XINT2, GPIO_INT_TYPE_RISING_EDGE);
            else
                GPIO_setInterruptType(GPIO_INT_XINT2, GPIO_INT_TYPE_FALLING_EDGE);
            GPIO_setInterruptPin(BSP_GPIO_CHANNEL_1, GPIO_INT_XINT2);
            GPIO_enableInterrupt(GPIO_INT_XINT2);
            Interrupt_register(INT_XINT2, &BSP_GPIO_ISR1);
            Interrupt_enable(INT_XINT2);
            break;
        case BSP_GPIO_CHANNEL_2:
            GPIO_setPadConfig(BSP_GPIO_CHANNEL_2, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
            g_bsp_gpio_info.cbFunc[2] = cbFunc;
            if(eIntType == BSP_GPIO_INT_TYPE_RISING_EDGE)
                GPIO_setInterruptType(GPIO_INT_XINT3, GPIO_INT_TYPE_RISING_EDGE);
            else
                GPIO_setInterruptType(GPIO_INT_XINT3, GPIO_INT_TYPE_FALLING_EDGE);
            GPIO_setInterruptPin(BSP_GPIO_CHANNEL_2, GPIO_INT_XINT3);
            GPIO_enableInterrupt(GPIO_INT_XINT3);
            Interrupt_register(INT_XINT3, &BSP_GPIO_ISR2);
            Interrupt_enable(INT_XINT3);
            break;
        case BSP_GPIO_CHANNEL_3:
            GPIO_setPadConfig(BSP_GPIO_CHANNEL_3, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
            g_bsp_gpio_info.cbFunc[3] = cbFunc;
            if(eIntType == BSP_GPIO_INT_TYPE_RISING_EDGE)
                GPIO_setInterruptType(GPIO_INT_XINT4, GPIO_INT_TYPE_RISING_EDGE);
            else
                GPIO_setInterruptType(GPIO_INT_XINT4, GPIO_INT_TYPE_FALLING_EDGE);
            GPIO_setInterruptPin(BSP_GPIO_CHANNEL_3, GPIO_INT_XINT4);
            GPIO_enableInterrupt(GPIO_INT_XINT4);
            Interrupt_register(INT_XINT4, &BSP_GPIO_ISR3);
            Interrupt_enable(INT_XINT4);
            break;
        case BSP_GPIO_CHANNEL_4:
            GPIO_setPadConfig(BSP_GPIO_CHANNEL_4, GPIO_PIN_TYPE_STD | GPIO_PIN_TYPE_PULLUP);
            g_bsp_gpio_info.cbFunc[4] = cbFunc;
            if(eIntType == BSP_GPIO_INT_TYPE_RISING_EDGE)
                GPIO_setInterruptType(GPIO_INT_XINT5, GPIO_INT_TYPE_RISING_EDGE);
            else
                GPIO_setInterruptType(GPIO_INT_XINT5, GPIO_INT_TYPE_FALLING_EDGE);
            GPIO_setInterruptPin(BSP_GPIO_CHANNEL_4, GPIO_INT_XINT5);
            GPIO_enableInterrupt(GPIO_INT_XINT5);
            Interrupt_register(INT_XINT5, &BSP_GPIO_ISR4);
            Interrupt_enable(INT_XINT5);
            break;
        default:
        /* error*/
        return BSP_RETURN_UNDEFINED_CASE;

    }

    return BSP_RETURN_SUCCESS;

}

///////////////////
__interrupt void BSP_GPIO_ISR0 (void)
{
    g_bsp_gpio_info.counter[0]++;

    if (g_bsp_gpio_info.cbFunc[0] != NULL)
    {
        /* run callback */
        g_bsp_gpio_info.cbFunc[0]();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);

}

///////////////////
__interrupt void BSP_GPIO_ISR1 (void)
{
    g_bsp_gpio_info.counter[1]++;

    if (g_bsp_gpio_info.cbFunc[1] != NULL)
    {
        /* run callback */
        g_bsp_gpio_info.cbFunc[1]();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

///////////////////
__interrupt void BSP_GPIO_ISR2 (void)
{
    g_bsp_gpio_info.counter[2]++;

    if (g_bsp_gpio_info.cbFunc[2] != NULL)
    {
        /* run callback */
        g_bsp_gpio_info.cbFunc[2]();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);

}

///////////////////
__interrupt void BSP_GPIO_ISR3 (void)
{
    g_bsp_gpio_info.counter[3]++;

    if (g_bsp_gpio_info.cbFunc[3] != NULL)
    {
        /* run callback */
        g_bsp_gpio_info.cbFunc[3]();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);

}

///////////////////
__interrupt void BSP_GPIO_ISR4 (void)
{
    g_bsp_gpio_info.counter[4]++;

    if (g_bsp_gpio_info.cbFunc[4] != NULL)
    {
        /* run callback */
        g_bsp_gpio_info.cbFunc[4]();
    }
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP12);

}

///////////////////
BSP_Return_E BSP_GPIO_SetPInLevel (BSP_GPIO_Channel_E eChannel, BSP_GPIO_Level_E eLevel)
{
    if(BSP_GPIO_LEVEL_LOW)
        GPIO_writePin(eChannel, 0);
    else if(BSP_GPIO_LEVEL_HIGH)
        GPIO_writePin(eChannel, 1);

    return BSP_RETURN_SUCCESS;
}

///////////////////
BSP_Return_E BSP_GPIO_SetPInDirection (BSP_GPIO_Channel_E eChannel, BSP_GPIO_Direction_E eDirection)
{
    if(eDirection == BSP_GPIO_DIRECTION_OUTPUT)
        GPIO_setDirectionMode(eChannel, GPIO_DIR_MODE_OUT);
    else if(eDirection == BSP_GPIO_DIRECTION_INPUT)
        GPIO_setDirectionMode(eChannel, GPIO_DIR_MODE_IN);

    return BSP_RETURN_SUCCESS;

}
///////////////////
BSP_Return_E BSP_GPIO_TogglePInLevel (BSP_GPIO_Channel_E eChannel)
{
    GPIO_togglePin(eChannel);

    return BSP_RETURN_SUCCESS;

}
///////////////////
BSP_GPIO_Level_E BSP_GPIO_GetPInLevel (BSP_GPIO_Channel_E eChannel)
{
    BSP_GPIO_Level_E val;

    val = GPIO_readPin(eChannel) ==0 ? BSP_GPIO_LEVEL_LOW : BSP_GPIO_LEVEL_HIGH;

    return(val);
}
