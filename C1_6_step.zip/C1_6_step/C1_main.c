
#include "C1_BSP_GeneralInclude.h"
void    six_steo_init(void);


#define UUT_MAIN_RUN_TEST

void main(void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;
    C1_BSP_MAIN_Info_S info;

    /* BSP main init*/
    eReturnCode = C1_BSP_MAIN_Init (&info);
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* trap */
        while (1);
    }

    /* UUT */
#ifdef UUT_MAIN_RUN_TEST
    //eReturnCode = C1_UUT_MAIN_Start (C1_UUT_MAIN_TEST_UART);
    eReturnCode = C1_UUT_MAIN_Start (C1_UUT_MAIN_TEST_IPC);
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* trap */
        while (TRUE);
    }
#endif
    six_steo_init();
    while (TRUE);
}
