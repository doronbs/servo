
#include "C1_UUT_Main.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///     Uart initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_UUT_UART_Init (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///     Uart tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void C1_UUT_UART_Test (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

#if 0
    UWORD16 index = 0;
    UWORD8 myMsg[500];

    for (index = 0; index < 1500; index++)
    {
        myMsg[index] = index;
    }

    while (1)
    {
        eReturnCode = C1_BSP_Uart_Write (&myMsg[0], 500);
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
            /* trap */
            while (1);
        }

        DEVICE_DELAY_US(50000);
    }
#endif


/* working */
#if 1
    UWORD8 myMsg[100];
    UWORD32 counter = 0, messageLength = 0;

    while (1)
    {
        messageLength = sprintf ((char *) myMsg, "Uart is working ---> %ld\r\n", counter++);

        eReturnCode = C1_BSP_UART_Write(&myMsg[0], messageLength);
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
            /* trap */
            while (1);
        }

        DEVICE_DELAY_US(500);
    }
#endif
}


