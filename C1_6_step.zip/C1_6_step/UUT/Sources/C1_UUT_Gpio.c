
#include "C1_BSP_GeneralInclude.h"

void UUT_GPIO_Callback_0 (void)
{
    static int count0=0;
    count0++;
}
void UUT_GPIO_Callback_2 (void)
{
    static int count2=0;
    count2++;
}
void C1_UUT_GPIO_Test (void)
{
    static int out_flg0=0, prev_flg0=0;
    static int out_flg2=0, prev_flg2=0;
    BSP_GPIO_Init();
    BSP_GPIO_SetPInDirection(BSP_GPIO_CHANNEL_3, BSP_GPIO_DIRECTION_OUTPUT);
    BSP_GPIO_SetPInDirection(BSP_GPIO_CHANNEL_0, BSP_GPIO_DIRECTION_INPUT);
    BSP_GPIO_SetPInDirection(BSP_GPIO_CHANNEL_1, BSP_GPIO_DIRECTION_OUTPUT);
    BSP_GPIO_SetPInDirection(BSP_GPIO_CHANNEL_2, BSP_GPIO_DIRECTION_INPUT);
    BSP_GPIO_SetCallback(BSP_GPIO_CHANNEL_0, UUT_GPIO_Callback_0, BSP_GPIO_INT_TYPE_RISING_EDGE);
    BSP_GPIO_SetCallback(BSP_GPIO_CHANNEL_2, UUT_GPIO_Callback_2, BSP_GPIO_INT_TYPE_FALLING_EDGE);
    while(1) {
        if(prev_flg0 != out_flg0) {
            prev_flg0 = out_flg0;
            BSP_GPIO_TogglePInLevel(BSP_GPIO_CHANNEL_3);
        }
        if(prev_flg2 != out_flg2) {
            prev_flg2 = out_flg2;
            BSP_GPIO_TogglePInLevel(BSP_GPIO_CHANNEL_1);
        }
    }
}
