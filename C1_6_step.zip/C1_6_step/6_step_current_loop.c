//#############################################################################
//
// FILE:   cla_ex5_adc_just_in_time.c
//
// TITLE:  Just-in-time ADC sampling with CLA
//
//! \addtogroup driver_example_list
//! <h1> Just-in-time ADC sampling with CLA </h1>
//!
//! This example showcases how to utilize early-interrupt feature of ADC
//! in combination with the low interrupt response of CLA to enable faster
//! system response and achieve high frequency control loops. EPWM1 is
//! configured to generate a PWM output signal of frequency 1 MHz and this
//! is also used to trigger the ADC sampling at each cycle. ADCA is
//! configured to sample the input on Channel 0 and to generate the early
//! interrupt at the end of S/H + offset cycles. This interrupt is used to
//! trigger the CLA control task. The CLA task implements the control logic
//! to update the duty of the PWM output based on reading the ADC sample data
//! just-in-time i.e. as soon as the ADC results gets latched.The early
//! interrupt feature and low interrupt latency of CLA allows to do some
//! pre-processing as well before reading the ADC data and still completes
//! updating the PWM output before the next interrupts comes in i.e. data read
//! and PWM update is done within a 1 MHz cycle. For illustration purposes,
//! 3-point moving average filter is used to simulate some processing and few
//! steps of the filtering code are done before reading the ADC result which
//! we consider as pre-processing code. The ADC interrupt offset is programmed
//! based on the cycles consumed by the pre-processing code.
//!
//! The calculation for interrupt offset value is as follows :-
//!   -ADC acquisition cycles programmed = 10 SYSCLKS
//!   -Conversion time for 12-bit data = 10.5 ADCCLKS =  N = 42 SYSCLKS
//!   -CLA task trigger to first instruction in Fetch delay = 4
//!   -Let the interrupt offset value be 'x'
//!   -The code inside CLA control task before ADC read takes below cycles :
//!                     Setting up profiling gpio : 3 cycles
//!                     Pre-processing : 13 cycles
//!                      Total = 3 + 13 = 16 cycles
//!
//! As described in device TRM, in order to read just-in-time the total delay
//! before reading ADC should be (N-2) cycles = 40 i.e.
//!                    : x + 4 + 16 = 40
//!                    : x = 20
//!
//! NOTE :- The optimization is off for this project and the cycles quoted above
//!         corresponds to that case.
//!
//! GPIO2 is used for profiling purposes. GPIO2 is set at the beginning of
//! CLA task 1 and is reset at the end of the task. Thus ON time of GPIO2
//! indicates the CLA activity. In order to validate the example functionality
//! , observe the GPIO0 (PWM output) and GPIO2 (profiling GPIO) on CRO.
//! The cycles difference between the rising edge of the GPIO0 and GPIO2
//! indicate the total delay from the time of ADC trigger to setting up of
//! profiling GPIO inside CLA task which should be around 44 cycles (220 ns)
//! based on the above calculation.
//!
//! \b External \b Connections \n
//!  - Provide constant DC input on ADCA0 for quick validation.
//!       GND -> Should observe PWM output duty = 0.1
//!       3.3V -> Should observe PWM output duty = 0.9
//!    Can also provide analog input in range 0 - 3.3V upto fs / 10 = 100 KHz for
//!    observing continuous duty variations
//!
//!  - Observe GPIO0 on oscilloscope
//!  - Observe GPIO2 on oscilloscope
//!
//! \b Watch \b Variables \n
//!  - None
//!
//
//#############################################################################
//
//
// $Copyright:
// Copyright (C) 2022 Texas Instruments Incorporated - http://www.ti.com
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//#############################################################################

//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "cla_ex5_adc_just_in_time_shared.h"
//#include "board.h"
//#include "my_board.h"
#include "DCLCLA.h"





#define myEPWM0_BASE EPWM1_BASE
#define myEPWM1_BASE EPWM2_BASE
#define myEPWM2_BASE EPWM7_BASE
#define myADC0_a0_BASE ADCA_BASE
#define myADC0_b0_BASE ADCB_BASE
#define myADC1_c1_BASE ADCC_BASE


//
// Function Prototypes
//
void initEPWM(void);
void initCLA(void);
void initADC(void);
void initADCSOC(void);
void setupProfileGpio(void);
void Board_init(void);


void myADC0_a0_init(void);
void myADC0_b0_init(void);
void myADC1_c1_init(void);

__attribute__((interrupt))  void cla1Isr1(void);

//
// Structure definitions
//

typedef struct {
    uint16_t loop1;
    uint16_t loop2;
}reference;

typedef struct {
    uint16_t loop1;
    uint16_t loop2;
}sensed;

typedef struct {
    float32_t loop1;
    float32_t loop2;
}control_out;

//void setupProfileGpio(void);
//void setupProfileGpio(void);   //enable servo
void init_pwm(uint32_t epwm_base ,uint16_t pwm_length);
extern void setupPWMs(uint32_t pwm_base,uint16_t pwmPeriod);

__attribute__((interrupt))  void cla1Isr1(void);
#pragma SET_DATA_SECTION("cla_shared")
volatile reference ref_data = {3500,3500}; // Target digital values for loops
volatile sensed sense_data = {0,0};   // ADC sensed data for both loops
volatile control_out control_out_data = {0.0,0.0}; // Outputs of controllers
volatile DCL_PI_CLA pi_loop1 = PI_CLA_DEFAULTS;  // Controller definition
#pragma SET_DATA_SECTION()   // Reset section to default

//
//
// Main
//


void six_steo_init(void)
{
     //
      // GPIO0 is set to EPWM1A,EPWM2A,EPWM4B,,EPWM5A
      //
      GPIO_setControllerCore(0, GPIO_CORE_CPU1_CLA1);
      GPIO_setPadConfig(0,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_0_EPWM1A);
      GPIO_setQualificationMode(0, GPIO_QUAL_SYNC);

      GPIO_setControllerCore(1, GPIO_CORE_CPU1_CLA1);
      GPIO_setPadConfig(1,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_1_EPWM1B);
      GPIO_setQualificationMode(1, GPIO_QUAL_SYNC);

      GPIO_setControllerCore(2, GPIO_CORE_CPU1_CLA1);
      GPIO_setPadConfig(2,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_2_EPWM2A);
      GPIO_setQualificationMode(2, GPIO_QUAL_SYNC);

      GPIO_setControllerCore(3, GPIO_CORE_CPU1_CLA1);
      GPIO_setPadConfig(3,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_3_EPWM2B);
      GPIO_setQualificationMode(3, GPIO_QUAL_SYNC);

      GPIO_setControllerCore(12, GPIO_CORE_CPU1_CLA1);
      GPIO_setPadConfig(12,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_12_EPWM7A);
      GPIO_setQualificationMode(12, GPIO_QUAL_SYNC);

      GPIO_setControllerCore(13, GPIO_CORE_CPU1_CLA1);
      GPIO_setPadConfig(13,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_13_EPWM7B);
      GPIO_setQualificationMode(13, GPIO_QUAL_SYNC);

      GPIO_setPadConfig(6,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_6_EPWM4A);
      GPIO_setControllerCore(6, GPIO_CORE_CPU1_CLA1);
      GPIO_setQualificationMode(6, GPIO_QUAL_SYNC);

      GPIO_setPadConfig(7,GPIO_PIN_TYPE_STD);
      GPIO_setPinConfig(GPIO_7_EPWM4B);
      GPIO_setControllerCore(7, GPIO_CORE_CPU1_CLA1);
      GPIO_setQualificationMode(7, GPIO_QUAL_SYNC);

  // hall io interface
      GPIO_setControllerCore(54, GPIO_CORE_CPU1_CLA1);
      GPIO_setPinConfig(GPIO_54_GPIO54);               // GPIO14 input hall A
      GPIO_setDirectionMode(54, GPIO_DIR_MODE_IN);
      GPIO_setPadConfig(54,GPIO_PIN_TYPE_PULLUP);

      GPIO_setControllerCore(55, GPIO_CORE_CPU1_CLA1);
      GPIO_setPinConfig(GPIO_55_GPIO55);               // GPIO14 input hall B
      GPIO_setDirectionMode(55, GPIO_DIR_MODE_IN);
      GPIO_setPadConfig(55,GPIO_PIN_TYPE_PULLUP);

      GPIO_setControllerCore(57, GPIO_CORE_CPU1_CLA1);
      GPIO_setPinConfig(GPIO_57_GPIO57);               // GPIO14 input hall A
      GPIO_setDirectionMode(57, GPIO_DIR_MODE_IN);
      GPIO_setPadConfig(57,GPIO_PIN_TYPE_PULLUP);

      GPIO_setControllerCore(21, GPIO_CORE_CPU1_CLA1);
      GPIO_setPinConfig(GPIO_21_GPIO21);               // GPIO14 input hall A
      GPIO_setDirectionMode(21, GPIO_DIR_MODE_OUT);
      GPIO_setPadConfig(21,GPIO_PIN_TYPE_PULLUP);


    //
    // GPIO2 is configured as output and CLA is assigned its controller
    //
    setupProfileGpio();

    //
    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    Interrupt_initVectorTable();

    //
    // Disable sync(Freeze clock to PWM as well)
    //
    SysCtl_disablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    EALLOW;
    //
    // Initialize EPWM1 module
    //
    initEPWM();

    //
    // Initialize ADC
    //
    initADC();

    //
    // Initialize resources
    //
    Board_init();
    initCLA();

    //
    // Enable global interrupts.
    //
    EINT;
    GPIO_writePin(21,0);
    //
    // Enable sync and clock to PWM
    //
    SysCtl_enablePeripheral(SYSCTL_PERIPH_CLK_TBCLKSYNC);

    return;
}

// ADC Initialization
//
// Function to configure and power up ADC A
//
void initADC(void)
{
        myADC0_a0_init();
        myADC0_b0_init();
        myADC1_c1_init();
    }

    void myADC0_a0_init() {
        //
        // ADC Initialization: Write ADC configurations and power up the ADC
        //
        // Configures the analog-to-digital converter module prescaler.
        //
        ADC_setPrescaler(myADC0_a0_BASE, ADC_CLK_DIV_4_0);
        //
        // Configures the analog-to-digital converter resolution and signal mode.
        //
    //  ADC_setMode(myADC0_a0_BASE, ADC_RESOLUTION_16BIT, ADC_MODE_SINGLE_ENDED);
        //
        // Sets the timing of the end-of-conversion pulse
        //
        ADC_setInterruptPulseMode(myADC0_a0_BASE, ADC_PULSE_END_OF_CONV);
        // Sets the timing of early interrupt generation.
        //
        ADC_setInterruptCycleOffset(myADC0_a0_BASE, 20U);

        //
        // Powers up the analog-to-digital converter core.
        //
        ADC_enableConverter(myADC0_a0_BASE);
        //
        // Delay for 1ms to allow ADC time to power up
        //
        DEVICE_DELAY_US(500);
        //
        // SOC Configuration: Setup ADC EPWM channel and trigger settings
        //
        // Disables SOC burst mode.
        //
        //ADC_disableBurstMode(myADC0_a0_BASE);
        //
        // Sets the priority mode of the SOCs.
        //
        ADC_setSOCPriority(myADC0_a0_BASE, ADC_PRI_ALL_ROUND_ROBIN);
        //
        // Start of Conversion 0 Configuration
        //
        //
        // Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
        //      SOC number      : 0
        //      Trigger         : ADC_TRIGGER_EPWM1_SOCA
        //      Channel         : ADC_CH_ADCIN2
        //      Sample Window   : 64 SYSCLK cycles
        //      Interrupt Trigger: ADC_INT_SOC_TRIGGER_ADCINT1
        //
        ADC_setupSOC(myADC0_a0_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN2, 64U);
        ADC_setInterruptSOCTrigger(myADC0_a0_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_ADCINT1);
        //
        // ADC Interrupt 1 Configuration
        //      Source  : ADC_SOC_NUMBER0
        //      Interrupt Source: enabled
        //      Continuous Mode : enabled
        //
        //
        ADC_setInterruptSource(myADC0_a0_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
        ADC_clearInterruptStatus(myADC0_a0_BASE, ADC_INT_NUMBER1);
        ADC_enableContinuousMode(myADC0_a0_BASE, ADC_INT_NUMBER1);
        ADC_enableInterrupt(myADC0_a0_BASE, ADC_INT_NUMBER1);
    }
    void myADC0_b0_init() {
        //
        // ADC Initialization: Write ADC configurations and power up the ADC
        //
        // Configures the analog-to-digital converter module prescaler.
        //
        ADC_setPrescaler(myADC0_b0_BASE, ADC_CLK_DIV_4_0);
        //
        // Configures the analog-to-digital converter resolution and signal mode.
        //
        ADC_setMode(myADC0_b0_BASE, ADC_RESOLUTION_16BIT, ADC_MODE_SINGLE_ENDED);
        //
        // Sets the timing of the end-of-conversion pulse
        //
        ADC_setInterruptPulseMode(myADC0_b0_BASE, ADC_PULSE_END_OF_CONV);   //
        // Sets the timing of early interrupt generation.
        //
        ADC_setInterruptCycleOffset(myADC0_b0_BASE, 20U);

        //
        // Powers up the analog-to-digital converter core.
        //
        ADC_enableConverter(myADC0_b0_BASE);
        //
        // Delay for 1ms to allow ADC time to power up
        //
        DEVICE_DELAY_US(500);
        //
        // SOC Configuration: Setup ADC EPWM channel and trigger settings
        //
        // Disables SOC burst mode.
        //
        //ADC_disableBurstMode(myADC0_b0_BASE);
        //
        // Sets the priority mode of the SOCs.
        //
        ADC_setSOCPriority(myADC0_b0_BASE, ADC_PRI_ALL_ROUND_ROBIN);
        //
        // Start of Conversion 0 Configuration
        //
        //
        // Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
        //      SOC number      : 0
        //      Trigger         : ADC_TRIGGER_EPWM1_SOCA
        //      Channel         : ADC_CH_ADCIN2
        //      Sample Window   : 64 SYSCLK cycles
        //      Interrupt Trigger: ADC_INT_SOC_TRIGGER_ADCINT1
        //
        ADC_setupSOC(myADC0_b0_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN2, 64U);
        ADC_setInterruptSOCTrigger(myADC0_b0_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_ADCINT1);
        //
        // ADC Interrupt 1 Configuration
        //      Source  : ADC_SOC_NUMBER0
        //      Interrupt Source: disabled
        //      Continuous Mode : disabled
        //
        //
        ADC_setInterruptSource(myADC0_b0_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
        ADC_disableContinuousMode(myADC0_b0_BASE, ADC_INT_NUMBER1);
        ADC_disableInterrupt(myADC0_b0_BASE, ADC_INT_NUMBER1);
    }
    void myADC1_c1_init() {
        //
        // ADC Initialization: Write ADC configurations and power up the ADC
        //
        // Configures the analog-to-digital converter module prescaler.
        //
        ADC_setPrescaler(myADC1_c1_BASE, ADC_CLK_DIV_4_0);
        //
        // Configures the analog-to-digital converter resolution and signal mode.
        //
        ADC_setMode(myADC1_c1_BASE, ADC_RESOLUTION_16BIT, ADC_MODE_SINGLE_ENDED);
        //
        // Sets the timing of the end-of-conversion pulse
        //
        ADC_setInterruptPulseMode(myADC1_c1_BASE, ADC_PULSE_END_OF_ACQ_WIN);
        //
        // Sets the timing of early interrupt generation.
        //
        ADC_setInterruptCycleOffset(myADC1_c1_BASE, 20U);
        //
        // Powers up the analog-to-digital converter core.
        //
        ADC_enableConverter(myADC1_c1_BASE);
        //
        // Delay for 1ms to allow ADC time to power up
        //
        DEVICE_DELAY_US(500);
        //
        // SOC Configuration: Setup ADC EPWM channel and trigger settings
        //
        // Disables SOC burst mode.
        //
        //ADC_disableBurstMode(myADC1_c1_BASE);
        //
        // Sets the priority mode of the SOCs.
        //
        ADC_setSOCPriority(myADC1_c1_BASE, ADC_PRI_ALL_ROUND_ROBIN);
        //
        // Start of Conversion 0 Configuration
        //
        //
        // Configures a start-of-conversion (SOC) in the ADC and its interrupt SOC trigger.
        //      SOC number      : 0
        //      Trigger         : ADC_TRIGGER_EPWM1_SOCA
        //      Channel         : ADC_CH_ADCIN2
        //      Sample Window   : 64 SYSCLK cycles
        //      Interrupt Trigger: ADC_INT_SOC_TRIGGER_ADCINT1
        //
        ADC_setupSOC(myADC1_c1_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA, ADC_CH_ADCIN2, 64U);
        ADC_setInterruptSOCTrigger(myADC1_c1_BASE, ADC_SOC_NUMBER0, ADC_INT_SOC_TRIGGER_ADCINT1);
        //
        // ADC Interrupt 1 Configuration
        //      Source  : ADC_SOC_NUMBER0
        //      Interrupt Source: disabled
        //      Continuous Mode : disabled
        //
        //
        ADC_setInterruptSource(myADC1_c1_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
        ADC_disableContinuousMode(myADC1_c1_BASE, ADC_INT_NUMBER1);
        ADC_disableInterrupt(myADC1_c1_BASE, ADC_INT_NUMBER1);

    DEVICE_DELAY_US(1000);
}

//
// ADC SOC Initialization
//
// Description: This function will configure the ADC, channel A0 to start
// its conversion on a trigger from EPWM1 (EPMW1SOCA). The ADC will sample this
// channel continuously. After each conversion it will assert ADCINT1, which
// is then used to trigger task 1 of the CLA
//
void initADCSOC(void)
{
    //
    // Configure SOC0 of ADCA
    // - SOC0 will be triggered by EPWM1SOCA
    // - SOC0 will convert pin A0 with a sample window of 10 SYSCLK cycles.
    // - EOC0 will be generated at the end of conversion
    // - SOC0 will sample on each trigger regardless of the interrupt flag
    //
    ADC_setupSOC(ADCA_BASE, ADC_SOC_NUMBER0, ADC_TRIGGER_EPWM1_SOCA,
                 ADC_CH_ADCIN2, 10);
    ADC_enableContinuousMode(ADCA_BASE, ADC_INT_NUMBER1);

    //
    // Set SOC0 to set the interrupt 1 flag. Enable the interrupt and make
    // sure its flag is cleared.
    //
    ADC_setInterruptSource(ADCA_BASE, ADC_INT_NUMBER1, ADC_SOC_NUMBER0);
    ADC_enableInterrupt(ADCA_BASE, ADC_INT_NUMBER1);
    ADC_clearInterruptStatus(ADCA_BASE, ADC_INT_NUMBER1);
}

//
// EPWM Initialization
//
// Description: EPWM1A will run at EPWM1_FREQ (1 MHz) and is used to generate
// the PWM output. It also serves as the sampling clock for ADC channel A0
// The default time base for the EPWM module is half the system clock
//
void initEPWM(void)
{
     EPWM_setEmulationMode(myEPWM0_BASE, EPWM_EMULATION_FREE_RUN);
     EPWM_setClockPrescaler(myEPWM0_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
     EPWM_setPeriodLoadMode(myEPWM0_BASE, EPWM_PERIOD_DIRECT_LOAD);
     EPWM_setTimeBasePeriod(myEPWM0_BASE, 1250);
     EPWM_setTimeBaseCounter(myEPWM0_BASE, 0);
     EPWM_setTimeBaseCounterMode(myEPWM0_BASE, EPWM_COUNTER_MODE_UP_DOWN);
     EPWM_setCountModeAfterSync(myEPWM0_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);
     EPWM_disablePhaseShiftLoad(myEPWM0_BASE);
     EPWM_setPhaseShift(myEPWM0_BASE, 0);
     EPWM_setSyncInPulseSource(myEPWM0_BASE, EPWM_SYNC_IN_PULSE_SRC_DISABLE);
     EPWM_enableSyncOutPulseSource(myEPWM0_BASE, EPWM_SYNC_OUT_PULSE_ON_CNTR_ZERO);
     EPWM_setCounterCompareValue(myEPWM0_BASE, EPWM_COUNTER_COMPARE_A, 625);
     EPWM_setCounterCompareShadowLoadMode(myEPWM0_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
     EPWM_setCounterCompareValue(myEPWM0_BASE, EPWM_COUNTER_COMPARE_B, 625);
     EPWM_setCounterCompareShadowLoadMode(myEPWM0_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
     EPWM_enableGlobalLoadRegisters(myEPWM0_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
     EPWM_enableGlobalLoadRegisters(myEPWM0_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
     EPWM_setActionQualifierAction(myEPWM0_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
     EPWM_setDeadBandDelayPolarity(myEPWM0_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
     EPWM_setDeadBandDelayMode(myEPWM0_BASE, EPWM_DB_RED, true);
     EPWM_setRisingEdgeDelayCountShadowLoadMode(myEPWM0_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
     EPWM_disableRisingEdgeDelayCountShadowLoadMode(myEPWM0_BASE);
     EPWM_setRisingEdgeDelayCount(myEPWM0_BASE, 50);
     EPWM_setDeadBandDelayMode(myEPWM0_BASE, EPWM_DB_FED, true);
     EPWM_setFallingEdgeDelayCountShadowLoadMode(myEPWM0_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
     EPWM_disableFallingEdgeDelayCountShadowLoadMode(myEPWM0_BASE);
     EPWM_setFallingEdgeDelayCount(myEPWM0_BASE, 60);
     EPWM_enableGlobalLoadRegisters(myEPWM0_BASE, EPWM_GL_REGISTER_DBRED_DBREDHR);

     EPWM_enableADCTrigger(myEPWM0_BASE, EPWM_SOC_A);
     EPWM_setADCTriggerSource(myEPWM0_BASE, EPWM_SOC_A, EPWM_SOC_TBCTR_ZERO_OR_PERIOD);
     EPWM_setADCTriggerEventPrescale(myEPWM0_BASE, EPWM_SOC_A, 1U);

     EPWM_setEmulationMode(myEPWM1_BASE, EPWM_EMULATION_FREE_RUN);
     EPWM_setClockPrescaler(myEPWM1_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
     EPWM_setPeriodLoadMode(myEPWM1_BASE, EPWM_PERIOD_DIRECT_LOAD);
     EPWM_setTimeBasePeriod(myEPWM1_BASE, 1250);
     EPWM_setupEPWMLinks(myEPWM1_BASE, EPWM_LINK_WITH_EPWM_1, EPWM_LINK_TBPRD);
     EPWM_enableGlobalLoadRegisters(myEPWM1_BASE, EPWM_GL_REGISTER_TBPRD_TBPRDHR);
     EPWM_setTimeBaseCounter(myEPWM1_BASE, 0);
     EPWM_setTimeBaseCounterMode(myEPWM1_BASE, EPWM_COUNTER_MODE_UP_DOWN);
     EPWM_setCountModeAfterSync(myEPWM1_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);
     EPWM_disablePhaseShiftLoad(myEPWM1_BASE);
     EPWM_setPhaseShift(myEPWM1_BASE, 0);
     EPWM_setSyncInPulseSource(myEPWM1_BASE, EPWM_SYNC_IN_PULSE_SRC_DISABLE);
     EPWM_enableSyncOutPulseSource(myEPWM1_BASE, EPWM_SYNC_OUT_PULSE_ON_CNTR_ZERO);
     EPWM_setCounterCompareValue(myEPWM1_BASE, EPWM_COUNTER_COMPARE_A, 625);
     EPWM_setCounterCompareShadowLoadMode(myEPWM1_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
     EPWM_setCounterCompareValue(myEPWM1_BASE, EPWM_COUNTER_COMPARE_B, 625);
     EPWM_setCounterCompareShadowLoadMode(myEPWM1_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
     EPWM_enableGlobalLoadRegisters(myEPWM1_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
     EPWM_enableGlobalLoadRegisters(myEPWM1_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
     EPWM_setActionQualifierAction(myEPWM1_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
     EPWM_setDeadBandDelayPolarity(myEPWM1_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
     EPWM_setDeadBandDelayMode(myEPWM1_BASE, EPWM_DB_RED, true);
     EPWM_setRisingEdgeDelayCountShadowLoadMode(myEPWM1_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
     EPWM_disableRisingEdgeDelayCountShadowLoadMode(myEPWM1_BASE);
     EPWM_setRisingEdgeDelayCount(myEPWM1_BASE, 50);
     EPWM_setDeadBandDelayMode(myEPWM1_BASE, EPWM_DB_FED, true);
     EPWM_setFallingEdgeDelayCountShadowLoadMode(myEPWM1_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
     EPWM_disableFallingEdgeDelayCountShadowLoadMode(myEPWM1_BASE);
     EPWM_setFallingEdgeDelayCount(myEPWM1_BASE, 60);
     EPWM_enableGlobalLoadRegisters(myEPWM1_BASE, EPWM_GL_REGISTER_DBRED_DBREDHR);
 //  EPWM_setEmulationMode(myEPWM2_BASE, EPWM_EMULATION_FREE_RUN);
     EPWM_setClockPrescaler(myEPWM2_BASE, EPWM_CLOCK_DIVIDER_1, EPWM_HSCLOCK_DIVIDER_1);
     EPWM_setPeriodLoadMode(myEPWM2_BASE, EPWM_PERIOD_DIRECT_LOAD);
     EPWM_setTimeBasePeriod(myEPWM2_BASE, 1250);
     EPWM_setupEPWMLinks(myEPWM2_BASE, EPWM_LINK_WITH_EPWM_1, EPWM_LINK_TBPRD);
     EPWM_enableGlobalLoadRegisters(myEPWM2_BASE, EPWM_GL_REGISTER_TBPRD_TBPRDHR);
     EPWM_setTimeBaseCounter(myEPWM2_BASE, 0);
     EPWM_setTimeBaseCounterMode(myEPWM2_BASE, EPWM_COUNTER_MODE_UP_DOWN);
     EPWM_setCountModeAfterSync(myEPWM2_BASE, EPWM_COUNT_MODE_UP_AFTER_SYNC);
     EPWM_disablePhaseShiftLoad(myEPWM2_BASE);
     EPWM_setPhaseShift(myEPWM2_BASE, 0);
     EPWM_setSyncInPulseSource(myEPWM2_BASE, EPWM_SYNC_IN_PULSE_SRC_DISABLE);
     EPWM_enableSyncOutPulseSource(myEPWM2_BASE, EPWM_SYNC_OUT_PULSE_ON_CNTR_ZERO);
     EPWM_setCounterCompareValue(myEPWM2_BASE, EPWM_COUNTER_COMPARE_A, 625);
     EPWM_setCounterCompareShadowLoadMode(myEPWM2_BASE, EPWM_COUNTER_COMPARE_A, EPWM_COMP_LOAD_ON_CNTR_ZERO);
     EPWM_setCounterCompareValue(myEPWM2_BASE, EPWM_COUNTER_COMPARE_B, 625);
     EPWM_setCounterCompareShadowLoadMode(myEPWM2_BASE, EPWM_COUNTER_COMPARE_B, EPWM_COMP_LOAD_ON_CNTR_ZERO);
     EPWM_enableGlobalLoadRegisters(myEPWM2_BASE, EPWM_GL_REGISTER_AQCTLA_AQCTLA2);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_A, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
     EPWM_enableGlobalLoadRegisters(myEPWM2_BASE, EPWM_GL_REGISTER_AQCTLB_AQCTLB2);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_ZERO);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_PERIOD);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPA);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_NO_CHANGE, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPA);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_HIGH, EPWM_AQ_OUTPUT_ON_TIMEBASE_UP_CMPB);
     EPWM_setActionQualifierAction(myEPWM2_BASE, EPWM_AQ_OUTPUT_B, EPWM_AQ_OUTPUT_LOW, EPWM_AQ_OUTPUT_ON_TIMEBASE_DOWN_CMPB);
     EPWM_setDeadBandDelayPolarity(myEPWM2_BASE, EPWM_DB_FED, EPWM_DB_POLARITY_ACTIVE_LOW);
     EPWM_setDeadBandDelayMode(myEPWM2_BASE, EPWM_DB_RED, true);
     EPWM_setRisingEdgeDelayCountShadowLoadMode(myEPWM2_BASE, EPWM_RED_LOAD_ON_CNTR_ZERO);
     EPWM_disableRisingEdgeDelayCountShadowLoadMode(myEPWM2_BASE);
     EPWM_setRisingEdgeDelayCount(myEPWM2_BASE, 50);
     EPWM_setDeadBandDelayMode(myEPWM2_BASE, EPWM_DB_FED, true);
     EPWM_setFallingEdgeDelayCountShadowLoadMode(myEPWM2_BASE, EPWM_FED_LOAD_ON_CNTR_ZERO);
     EPWM_disableFallingEdgeDelayCountShadowLoadMode(myEPWM2_BASE);
     EPWM_setFallingEdgeDelayCount(myEPWM2_BASE, 60);
     EPWM_enableGlobalLoadRegisters(myEPWM2_BASE, EPWM_GL_REGISTER_DBRED_DBREDHR);
}

//
// CLA Initialization
//
//
void initCLA(void)
{
    //
    // Force task 8, the one time initialization task to initialize
    // the CLA global variables
    //
    CLA_forceTasks(CLA1_BASE, CLA_TASKFLAG_8);
}

//
// Setting up GPIO2 for profiling and set CLA as its controller
//
void setupProfileGpio(void)
{
        GPIO_setDirectionMode(2,GPIO_DIR_MODE_OUT);
        GPIO_setQualificationMode(2,GPIO_QUAL_SYNC);
        GPIO_setPinConfig(GPIO_2_GPIO2);
        GPIO_writePin(2,0);
        GPIO_setControllerCore(2, GPIO_CORE_CPU1_CLA1);
}
