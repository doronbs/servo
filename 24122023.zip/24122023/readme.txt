1. cla control loop infrastructure only
2. the controller is tms320f280049c + drv8320
3. we see the epwm 40kHz in scope
4. we see the epwm init, adc soc init, cla code, pid function.