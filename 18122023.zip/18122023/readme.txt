1. program the C1 & CM boot applicatios & disconnect debugger (off & on the board)
2. run python application udp_388d_client_send_hex_c1_cm_mon2.py
3. select "burn" the one file that include C1 and CM application (c1_cm.hex)
4. send verify_c1 and verify_cm for test the files (the embedded is read all file from flash and sum it, the sum should be 0 for c1 & for cm)
5. send run_c1 command from python & run_cm for running both c1 & cm