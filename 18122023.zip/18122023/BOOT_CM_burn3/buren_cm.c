/*
 * buren_c1.c
 *
 *  Created on: Aug 17, 2023
 *      Author: baruch e
 */
//
// Included Files
#include <string.h>



#include "driverlib_cm/ethernet.h"
#include "driverlib_cm/gpio.h"
#include "driverlib_cm/interrupt.h"
#include "driverlib_cm/flash.h"

#include "driverlib_cm/sysctl.h"
#include "driverlib_cm/systick.h"



//
// Included ipc Files
//
//#include "arch.h"
#include "cm.h"
#include "ipc.h"
#include "ipc_messages.h"
typedef uint8_t   u8_t;
typedef uint16_t  u16_t;

//
// Defines&
//
#define IPC_CMD_READ_MEM   0x1001
#define IPC_CMD_RESP       0x2001

#define TEST_PASS          0x5555
#define TEST_FAIL          0xAAAA
#define hex2000_PASS       0x5555
#define hex2000_FAIL       0xAAAA
#define hex2000_flash_FAIL       0xBBBB
#define PAYLOAD 1088

uint16_t flash_data_len , flash_data_index ,data_dig;
uint32_t flash_address;
uint32_t load_start_address;
uint16_t length;
uint16_t check_sum,check_sum1;
u8_t  flash_data[256];
uint16_t index;
uint16_t address_length;
uint16_t msg_type;




extern uint32_t writeData[375];
uint32_t hex_file_line[32];
uint32_t command, data;
uint16_t status;
extern uint32_t packetData[];

uint16_t flash_status;
extern const uint32_t boot_status_cm_cmdm;
extern const uint32_t start_udp_cmd;
extern const uint32_t start_udp_2_cmd;
extern const uint32_t send_load_line_cmd;
extern const uint32_t send_last_load_line_cmd;

//
// CM response
//

extern const uint32_t cm_status_init_cmd;
extern const uint32_t boot_response_fail_cmd;
extern const uint32_t boot_response_init_cmd;
extern const uint32_t boot_response_udp_ready_cmd ;
extern const uint32_t boot_response_udp_not_ready_cmdy;
extern const uint32_t cm_start_udp_cmd;

extern u8_t buf_rx[PAYLOAD];
extern uint16_t buf_rx_cnt_in,buf_rx_cnt_out;
extern uint16_t buf_rx_cnt_in_cm,buf_rx_cnt_out_cm;
extern volatile u8_t buf_tx[4][PAYLOAD];
extern uint16_t eth_message_counter,eth_mwssage_send;
extern uint16_t eth_message_lengh[4];
extern uint16_t long_UDP_complete;
extern char *buf_tx_start_msg;
extern uint32_t buf_tx_start_msg_count;
extern struct udp_pcb *g_upcb;
extern struct pbuf *pbuf1_tx;

struct flash_im
{
    uint32_t start_adress;  // delayi
    uint32_t sigment_data[100];  // lne width
    uint16_t first_sig;  // lne width
    uint16_t num_of_sig;  // lne width
};
struct flash_im flash_sigment;
uint16_t burn_status;
uint32_t hex2000_cs;
uint32_t flash_index,flash_cs;
uint32_t *flash_lw;

extern bool Program_hex2000_line_ecc( uint32_t flash_address , uint32_t* flash_data , uint16_t length);
extern void send_udp_message(u16_t msg_len);
uint16_t run_cmd(void);
uint16_t verify_cmd(void);
u8_t cmd_status;


uint16_t asc2num(uint16_t asc2num)
{
    uint16_t result;
    if ((asc2num >= '0') &&   asc2num <= '9')
        result = (asc2num - '0') & 0xff;
    else if ((asc2num >= 'A') &&   asc2num <= 'F')
        result = ((asc2num - 'A') & 0xff) +10;
    else if ((asc2num >= 'a') &&   asc2num <= 'f')
        result = ((asc2num - 'a') & 0xff) +10;
    else result = 0x8000;
    hex2000_cs += result;
    return result;
}


uint16_t hex2000TO_flashIM(uint32_t *eth_buff,uint32_t data)
{

hex2000_cs = 0;
    if ((*eth_buff & 0xff) == 0x25 ) // '%'
    {
        length =  asc2num((*eth_buff >> 8) & 0xff ) *16 + asc2num((*eth_buff >> 16) & 0xff );
        msg_type = asc2num((*eth_buff++ >> 24) & 0xff);
        check_sum1 = hex2000_cs;
        check_sum =   asc2num((*eth_buff ) & 0xff ) * 16 + asc2num((*eth_buff >> 8) & 0xff );
        hex2000_cs = check_sum1;
        address_length =   asc2num((*eth_buff >> 16) & 0xff);
        flash_address =   asc2num((*eth_buff++ >> 24) & 0xff) * 0x10000000;
        flash_address +=  asc2num((*eth_buff) & 0xff) * 0x1000000;
        flash_address +=  asc2num((*eth_buff >> 8) & 0xff) * 0x100000;
        flash_address +=  asc2num((*eth_buff >> 16) & 0xff) * 0x10000;
        flash_address +=  asc2num((*eth_buff++ >> 24) & 0xff) * 0x1000;
        flash_address +=  asc2num((*eth_buff) & 0xff) * 0x100;
        flash_address +=  asc2num((*eth_buff >> 8) & 0xff) * 0x10;
        flash_address +=  asc2num((*eth_buff >> 16) & 0xff);
        flash_data_len  = length - 14;
         for (flash_data_index = 0 ;flash_data_index < flash_data_len/2  ;  flash_data_index+=4 )
         {

             data_dig = asc2num((*eth_buff++ >> 24) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index + 3] = data_dig  *16;
             }
             data_dig = asc2num((*eth_buff) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index + 3] +=  data_dig;
             }
             data_dig = asc2num((*eth_buff >> 8) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index + 2] = data_dig * 16;
             }
             data_dig = asc2num((*eth_buff >> 16) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index + 2] += data_dig;
             }
             data_dig = asc2num((*eth_buff++ >> 24) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index + 1] = data_dig  *16;
             }
             data_dig = asc2num((*eth_buff) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index + 1] +=  data_dig;
             }
             data_dig = asc2num((*eth_buff >> 8) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index] = data_dig * 16;
             }
             data_dig = asc2num((*eth_buff >> 16) & 0xff);
             if (data_dig != 0x8000)
             {
                flash_data[flash_data_index] += data_dig;
             }

         }
         if(msg_type == 8)
         {
             load_start_address = flash_address;
             flash_address &= 0xFFFF0000;
             flash_lw = (uint32_t *)flash_address;
             flash_address += 8;
             flash_data[flash_data_index++] =  (load_start_address) & 0xFF;
             flash_data[flash_data_index++] =  (load_start_address>> 8 ) & 0xFF;
             flash_data[flash_data_index++] =  (load_start_address>> 16 ) & 0xFF;
             flash_data[flash_data_index++] =  (load_start_address>> 24 ) & 0xFF;

             flash_data_len = 16;
             flash_cs = 0;

             for (flash_index = 0 ; flash_index < 0x30000/4 ; flash_index++)
                 flash_cs += *flash_lw++;
             flash_cs += load_start_address;
             flash_cs = -flash_cs - 2;

             flash_data[flash_data_index++] =  (flash_cs) & 0xFF;
             flash_data[flash_data_index++] =  (flash_cs>> 8 ) & 0xFF;
             flash_data[flash_data_index++] =  (flash_cs>> 16 ) & 0xFF;
             flash_data[flash_data_index++] =  (flash_cs>> 24 ) & 0xFF;

             flash_data[flash_data_index++] = 0xff;
             flash_data[flash_data_index++] = 0xff;
             flash_data[flash_data_index++] = 0xff;
             flash_data[flash_data_index++] = 0xff;
         }
             if(hex2000_cs < 0x8000)
             {
                 if((hex2000_cs & 0xff) == check_sum )
                     return hex2000_PASS;
             }
             else return hex2000_FAIL;
    }
    return hex2000_PASS;
}
extern void flash_init(void);

uint16_t run_cmd(void)
{
   uint32_t *run_ptr;
   uint32_t start_adr;

   run_ptr = (uint32_t *) 0x230008;
   start_adr = *run_ptr;
   if (*run_ptr != 0xffffffff)
   {
       asm("    MOV r1,#8 ");
       asm("    MOVT r1, #0x23 " );
       asm("    LDR r1,[r1] ");
       asm("    BLX R1  ");
    return 1;
   }
   else return 0;
}



uint16_t verify_cmd(void)
{
   uint32_t mem_index;
   uint32_t *flash_ptr_ptr;
   uint32_t flash_cs;
   flash_cs = 0;
   flash_ptr_ptr = (uint32_t *) 0x230000;
   for (mem_index = 0 ;  mem_index < 0x30000/4 ; mem_index++)
       flash_cs += *flash_ptr_ptr++;
   if (flash_cs == 0)
       return true;
   else
       return false;

}


