extern void sci_drv(void);
extern uint16_t get_sci_input(void);
extern uint16_t send_sci_output(void);
extern unsigned char in_buff[256];
extern uint16_t  in_buf_indx_in, in_buf_indx_out;
extern unsigned char out_buff[256];
extern uint16_t out_buf_indx_in, out_buf_indx_out;

