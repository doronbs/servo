/*
 * buren_c1.c
 *
 *  Created on: Aug 17, 2023
 *      Author: baruch e
 */
//
// Included Files
//
#include "driverlib.h"
#include "device.h"
#include "ipc_messages.h"
#include "sci_drv.h"


extern bool Program_hex2000_line_ecc( uint32_t flash_address , uint16_t* flash_data , uint16_t length);
extern void flash_erase();
//
// Defines&
//

#define IPC_CMD_READ_MEM   0x1001
#define IPC_CMD_RESP       0x2001

#define TEST_PASS          0x5555
#define TEST_FAIL          0xAAAA
#define hex2000_PASS       0x5555
#define hex2000_FAIL       0xAAAA
#define hex2000_finish     0xAA55

extern uint32_t eth_message[375];
uint32_t hex_file_line[32];
uint32_t command, data;
uint16_t status;
extern uint32_t packetData[];


extern const uint32_t boot_status_cm_cmdm;
extern const uint32_t start_udp_cmd;
extern const uint32_t start_udp_2_cmd;
extern const uint32_t send_load_line_cmd;
extern const uint32_t send_last_load_line_cmd;

//
// CM response
//

extern const uint32_t cm_status_init_cmd;
extern const uint32_t boot_response_fail_cmd;
extern const uint32_t boot_response_init_cmd;
extern const uint32_t boot_response_udp_ready_cmd ;
extern const uint32_t boot_response_udp_not_ready_cmdy;
extern const uint32_t cm_start_udp_cmd;
extern const uint32_t send_load_finish_cmd;
bool flash_burn_status;

uint16_t flash_data_len , flash_data_index ,data_dig;
uint32_t flash_address;
uint16_t length;
uint32_t check_sum,check_sum1,fill_index ;
uint16_t flash_data[128];
uint16_t flash_word;
uint16_t index;
uint16_t address_length;
uint16_t msg_type;
uint16_t sci_status;
uint16_t run_flag = 0;


struct flash_im
{
    uint32_t start_adress;  // delayi
    uint32_t sigment_data[100];  // lne width
    uint16_t first_sig;  // lne width
    uint16_t num_of_sig;  // lne width
};
struct flash_im flash_sigment;
uint32_t load_start_address = 0;
uint32_t line_num = 0;
uint32_t *flash_addr_ptr;
uint32_t flash_cs_all;
uint32_t flash_index;

uint16_t burn_status;
uint32_t hex2000_cs;
uint16_t asc2num(uint16_t asc2num_d)
{
    uint32_t result;
    if ((asc2num_d >= '0') &&   asc2num_d <= '9')
        result = (asc2num_d - '0') & 0xff;
    else if ((asc2num_d >= 'A') &&   asc2num_d <= 'F')
        result = ((asc2num_d - 'A') & 0xff) +10;
    else if ((asc2num_d >= 'a') &&   asc2num_d <= 'f')
        result = ((asc2num_d - 'a') & 0xff) +10;
    else result = 0x8000;
    hex2000_cs += result;
    return result;
}


uint16_t hex2000TO_flashIM(uint32_t *eth_buff,uint32_t data)
{

    if ((*eth_buff & 0xff) == 0x25 )
    {
        hex2000_cs = 0;
        length =  asc2num((*eth_buff >> 8) & 0xff ) *16 + asc2num((*eth_buff >> 16) & 0xff );
        flash_data[length +1] = 0xFFFF;  // peding for long word boundry.
        msg_type = asc2num((*eth_buff++ >> 24) & 0xff);
        check_sum1 = hex2000_cs;
        check_sum =   asc2num((*eth_buff ) & 0xff ) * 16 + asc2num((*eth_buff >> 8) & 0xff );
        hex2000_cs = check_sum1;
        address_length =   asc2num((*eth_buff >> 16) & 0xff);
        flash_address =   asc2num((*eth_buff++ >> 24) & 0xff) * 0x10000000;
        flash_address +=  asc2num((*eth_buff) & 0xff) * 0x1000000;
        flash_address +=  asc2num((*eth_buff >> 8) & 0xff) * 0x100000;
        flash_address +=  asc2num((*eth_buff >> 16) & 0xff) * 0x10000;
        flash_address +=  asc2num((*eth_buff++ >> 24) & 0xff) * 0x1000;
        flash_address +=  asc2num((*eth_buff) & 0xff) * 0x100;
        flash_address +=  asc2num((*eth_buff >> 8) & 0xff) * 0x10;
        flash_address +=  asc2num((*eth_buff >> 16) & 0xff);
        flash_data_len  = length - 14;
         for (flash_data_index = 0 ;flash_data_index < ((flash_data_len +3)/4) ;  flash_data_index++)
         {

             data_dig = asc2num((eth_message[3+flash_data_index] >> 24) & 0xff);
             if (data_dig != 0x8000)
             {
                 flash_word = data_dig;
             }
             data_dig = asc2num((eth_message[4+flash_data_index]) & 0xff);
             if (data_dig != 0x8000)
             {
                 flash_word = flash_word *16 + data_dig;
             }
             data_dig = asc2num((eth_message[4+flash_data_index] >> 8) & 0xff);
             if (data_dig != 0x8000)
             {
                 flash_word = flash_word *16 + data_dig;
             }
             data_dig = asc2num((eth_message[4+flash_data_index] >> 16) & 0xff);
             if (data_dig != 0x8000)
             {
                 flash_word= flash_word *16 + data_dig;
             }
             flash_data[flash_data_index] = flash_word;
         }
             check_sum1 = 8 - ((flash_data_index) % 8);
             fill_index = 0;
             if (check_sum1 != 8)   // add to 8 word boundry
             {
                 while (check_sum1 != 0)
                 {
                     flash_data[flash_data_index+fill_index] =0xFFFF;
                     check_sum1--;
                     fill_index++;
                 }
             }

             if (msg_type == 8)
             {
                 load_start_address = flash_address;
                 flash_address += 8;
                 flash_data[0] =  load_start_address & 0xFFFF;
                 flash_data[1] =  (load_start_address >> 16 ) & 0xFFFF;
                 flash_cs_all = 0;
                 flash_addr_ptr = load_start_address;
                 for (flash_index = 0 ; flash_index < 0x5800 ; flash_index++)
                     flash_cs_all = *flash_addr_ptr++;
                 flash_cs_all += 2;
                 flash_data[2] =  flash_cs_all & 0xFFFF;
                 flash_data[3] =  (flash_cs_all >> 16 ) & 0xFFFF;

                 flash_data_len = 32;
             }
             if(hex2000_cs < 0x8000)
             {
                 if((hex2000_cs & 0xff) == (check_sum & 0xff) )
                 {
                     if (line_num == 0)
                     {
                         flash_erase();
                         line_num = 1;
                     }
                     flash_burn_status = Program_hex2000_line_ecc(flash_address , &flash_data , flash_data_len/2);
                     if(msg_type == 8)
                         {
                             Flash_releasePumpSemaphore();
                             return hex2000_finish;
                         }
                     else return hex2000_PASS;
                 }
             }
             else return hex2000_FAIL;
         }
    }

uint32_t  buren_c1(void)
{
uint32_t  cm_response;
bool ipc_read_state;
    IPC_clearFlagLtoR(IPC_CPU1_L_CM_R, IPC_FLAG0);
    IPC_clearFlagLtoR(IPC_CPU1_L_CM_R, IPC_FLAG1);
    packetData[0] = send_load_line ;
    uint32_t *program_start;
    while (1)
    {
    //
     // Wait for acknowledgment
     //
     //
     // Read the command
     //

     IPC_readCommand(IPC_CPU1_L_CM_R, IPC_FLAG1, IPC_ADDR_CORRECTION_ENABLE,
                     &command, &eth_message, &data);

     IPC_ackFlagRtoL(IPC_CPU1_L_CM_R, IPC_FLAG1);


     if(command == IPC_CMD_READ_MEM)
     {

         if ((eth_message[0] & 0xff) == 0x25 )
         {
             status = hex2000TO_flashIM(eth_message,data);
             if (status == hex2000_PASS)
             {
                 packetData[0] = send_load_line_cmd ;
             }
             else if (status == hex2000_FAIL)
             {
             packetData[0] = send_last_load_line_cmd ;
             }
             else if (status == hex2000_finish)
             {
             packetData[0] = send_load_finish_cmd ;
             }

         }
         else if ((eth_message[0] & 0xff) == 0x7 )
         {
/*             program_start =(uint32_t *) 0xa8008;
             if (*program_start != 0xffffffff)
                 packetData[0] = send_program_load_cmd ;
             else
                 packetData[0] = send_no_program ;

*/
             flash_addr_ptr = 0xA80000;
             flash_cs_all = 0;
             for (flash_index = 0 ; flash_index < 0x5800 ; flash_index++)
                 flash_cs_all += *flash_addr_ptr++;
             if (flash_cs_all == 0)
                 packetData[0] = 14;
             else
                 packetData[0] = 15;

         }
         else if ((eth_message[0] & 0xff) == 0x8 )
         {
             program_start = (uint32_t *) 0xa8008;
             if (*program_start != 0xffffffff)
             {
                 packetData[0] = send_run_cmd ;
                 run_flag = 1;
             }
             else
                 packetData[0] = send_no_run_cmd ;
         }
     }
     else
     {
         if(command != 0)
             while(1);
     }
     IPC_sendCommand(IPC_CPU1_L_CM_R, IPC_FLAG0, IPC_ADDR_CORRECTION_ENABLE,
                 IPC_CMD_READ_MEM,packetData,  1);
     //
     // Wait for acknowledgment
     //
         IPC_waitForAck(IPC_CPU1_L_CM_R, IPC_FLAG0);
         cm_response = IPC_getResponse(IPC_CPU1_L_CM_R);
         while (run_flag != 0  )
         {
             asm(" movl xar2,#0xa8008");
             asm(" movl xar7,*xar2");
             asm(" LB *xar7");
             asm(" nop");
             asm(" nop");
             asm(" nop");
             asm(" nop");
         }


//
//       wait for data from cm with hex2000 line
//


         IPC_waitForFlag(IPC_CPU1_L_CM_R, IPC_FLAG1);
//
// echo via sci a
//
         get_sci_input();

         while (in_buf_indx_in != in_buf_indx_out)
         {
            out_buff[out_buf_indx_in] = in_buff[in_buf_indx_out];
            in_buf_indx_out = in_buf_indx_out++ & 0xff;
            out_buf_indx_in = out_buf_indx_in++ & 0xff;
         }
         send_sci_output();

    }




    return  hex2000_PASS;

}



