import os
import socket
import random
import sys
import time
import timeit
sys.path.insert(0,'D:\OneDrive\OneDrive - DR Utilight Corp ltd\python3\chatlib')

#SERVER_IP = "127.0.0.1"  # Our server will run on same computer as client
SERVER_IP = "192.168.141.4"  # Our server will not run on same computer as client
#SERVER_PbORT = 8821
SERVER_PORT = 28001
#MAX_MSG_SIZE = 1024                                                                                                                               trans_data
MAX_MSG_SIZE = 1088
CM_ACK = 0xAAAA
CM_NACK = 0X5555


def main():
    hex_file = open('c1_cm.hex', 'r')
    print("client is active")
    server_addr = (SERVER_IP , SERVER_PORT)
    my_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    #my_socket.bind(server_addr)
    my_socket.setblocking(False)
    my_socket.settimeout(100000)
    print(my_socket.type)
    print("server ip = ",SERVER_IP ,  "port = " , SERVER_PORT  )
    response = "START"
    my_socket.sendto(response.encode(), server_addr)   # send line
    print(response)
    (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
    data = server_message.decode()
    print("server_SEND",server_message, data)
    burn_count = 0
    burn_cm_flag = 0
    while (1):
       cmd = input("type your command : burn or verify_c1 or run_c1 or verify_cm or run_cm : ") 
       if cmd != "burn":
           my_socket.sendto(cmd.encode(), server_addr)   # send line
           data = server_message.decode()
           (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
           data = server_message.decode()
           if ord(data[0]) == 4:
              (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
              data = server_message.decode()


           print (ord(data[0]))
           if ord(data[0]) == 10: print  ("cm_program_load")
           if ord(data[0]) == 11: print  ("cm_no program_load")
           if ord(data[0]) == 12: print  ("C1_RUN")
           if ord(data[0]) == 13: print  ("C1_RUN FAIL")
           if ord(data[0]) == 14: print  ("C1_verify pass")
           if ord(data[0]) == 15: print  ("C1_verify fail")
           if ord(data[0]) == 20: print  ("CM_program_load")
           if ord(data[0]) == 21: print  ("CM_no program_load")
           if ord(data[0]) == 24: print  ("CM_verify pass")
           if ord(data[0]) == 25: print  ("CM_verify fail")
       else:
           if burn_count == 0:
              while cmd == "burn":
                   response = hex_file.readline()
                   if response == '':
                     hex_file.close 
                     break
                   burn_count = 1
                   print("Client sent: " , response)
                   data = CM_NACK
                   while data == CM_NACK:
                        my_socket.sendto(response.encode(), server_addr)   # send line
                        time.sleep(0.005)
                        (server_message, server_address) = my_socket.recvfrom(MAX_MSG_SIZE)
                        data = server_message.decode()
                        print("response =",data)
                        if ord(data[0]) == 17: 
                             print  ("c1 burn complite")
                             burn_cm_flag = 1
                             data = CM_NACK
           else:
                print("please turn off power. you can't burn now")
if __name__ == '__main__':
    main()
