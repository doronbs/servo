/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Copyright © 2020 ISRAEL AEROSPACE INDUSTRY LTD <IAI LTD>
//  The information contained in this work is proprietary and confidential
//  information of IAI LTD. Any unauthorized reproduction, use or disclosure
//  of this material, or any part thereof, is strictly prohibited. This work and
//  information is intended solely for the internal use of authorized IAI LTD
//  customers, for the limited purposes for which this work has been provided for.
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  FILE INFORMATION
//
//  File:
//		CM_BSP_ETHERNET.h
//
//  Revision History:
// 		Created         Aug 2023       Doron Ben Sheetreet <doronbs>
//
//  Description:
//		CM_BSP_ETHERNET
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __CM_BSP_ETHERNET_H__
#define __CM_BSP_ETHERNET_H__

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//												       DEFINITIONS											           //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/* TX */
#define CM_BSP_ETHERNET_TX_NUMBER_BUFEER_MAX           (10)
#define CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX          (1460)

/* RX */
#define CM_BSP_ETHERNET_RX_NUMBER_BUFEER_MAX           (10)
#define CM_BSP_ETHERNET_RX_MESSAGE_LENGTH_MAX          (1450)

#define CM_BSP_ETHERNET_NET_MASK                       (0xFFFFFF00)
#define CM_BSP_ETHERNET_GATEWAY_ADDRESS                (0x00000000)

#define CM_BSP_ETHERNET_PHY_ADDRESS                    (1)

#ifdef SLAVE
#define CM_BSP_ETHERNET_MAC_ADDRESS                    (0x00F263A4)
#else
#define CM_BSP_ETHERNET_MAC_ADDRESS                    (0x00F263A8)
#endif

#ifdef SLAVE
#define CM_BSP_ETHERNET_LOCAL_IP_ADDRESS                 (0xC0A80132)  /* 192.168.1.50 */
#define CM_BSP_ETHERNET_REMOTE_IP_ADDRESS                (0xC0A80164)  /* 192.168.1.100 */
#else
#define CM_BSP_ETHERNET_LOCAL_IP_ADDRESS                 (0xC0A80164)  /* 192.168.1.100 */
#define CM_BSP_ETHERNET_REMOTE_IP_ADDRESS                (0xC0A80132)  /* 192.168.1.50 */
#endif

#ifdef SLAVE
#define CM_BSP_ETHERNET_LOCAL_PORT                       (28000)
#define CM_BSP_ETHERNET_REMOTE_PORT                      (55000)
#else
#define CM_BSP_ETHERNET_LOCAL_PORT                       (55000)
#define CM_BSP_ETHERNET_REMOTE_PORT                      (28000)
#endif

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//												 LOCAL MACROS and ENUMs 											   //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef enum CM_BSP_ETHERNET_Channel_Enum
{
	CM_BSP_ETHERNET_CHANNEL_0 = 0,
	CM_BSP_ETHERNET_CHANNEL_1,
	CM_BSP_ETHERNET_CHANNEL_2,
	CM_BSP_ETHERNET_CHANNEL_3,
	CM_BSP_ETHERNET_CHANNEL_MAX
} CM_BSP_ETHERNET_Channel_E;

typedef enum CM_BSP_ETHERNET_LinkStatus_Enum
{
    CM_BSP_ETHERNET_LINK_STATUS_NO_LINK_ESTABLISHED = 0,
    CM_BSP_ETHERNET_LINK_STATUS_VALID_LINK_ESTABLISHED = 1
} CM_BSP_ETHERNET_LinkStatus_E;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//												       STRUCTs											               //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct CM_BSP_ETHERNET_Phy_Address_0010_Struct
{
    UWORD16 LinkStatus              : 1;
    UWORD16 SpeedStatus             : 1;
    UWORD16 DuplexStatus            : 1;
    UWORD16 MIILoopbackStatus       : 1;
    UWORD16 AutoNegotiationStatus   : 1;
    UWORD16 JabberDetect            : 1;
    UWORD16 RemoteFault             : 1;
    UWORD16 MIIInterrupt            : 1;
    UWORD16 PageReceived            : 1;
    UWORD16 DescramblerLock         : 1;
    UWORD16 SignalDetect            : 1;
    UWORD16 FalseCarrierSenseLatch  : 1;
    UWORD16 PolarityStatus          : 1;
    UWORD16 ReceiveErrorLatch       : 1;
    UWORD16 MDIMDIXMode             : 1;
    UWORD16 Reserved                : 1;
} CM_BSP_ETHERNET_Phy_Address_0010_S;

typedef struct CM_BSP_ETHERNET_Params_Struct
{
	//BOOL isCreated;
	char ip[16];
	unsigned long port;
} CM_BSP_ETHERNET_Params_S;

typedef struct CM_BSP_ETHERNET_Info_Struct
{
    struct udp_pcb *pUdpPcb;
    struct pbuf *pTxBuffer;
    ip_addr_t ipAddress;
    UWORD8 pucMACArray[8];

    /* tx */
    UWORD8 txBuffer[CM_BSP_ETHERNET_TX_NUMBER_BUFEER_MAX][CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX];

    /* rx */
    UWORD8 rxBuffer[CM_BSP_ETHERNET_RX_NUMBER_BUFEER_MAX][CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX];
    UWORD16 rxBufferLength[CM_BSP_ETHERNET_RX_NUMBER_BUFEER_MAX];
    UWORD16 rxNumberOfMessages;
} CM_BSP_ETHERNET_Info_S;

//libi
typedef struct CM_BSP_ETHERNET_RxInfo_Struct
{
    //RX
    UWORD8 rxData[CM_BSP_ETHERNET_RX_NUMBER_BUFEER_MAX][CM_BSP_ETHERNET_RX_MESSAGE_LENGTH_MAX];
    UWORD16 rxDataLength[CM_BSP_ETHERNET_RX_NUMBER_BUFEER_MAX];
    UWORD16 rxMessages;

} CM_BSP_ETHERNET_RxInfo_S;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//												   EXTERNAL FUNCTIONS											       //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///
///
///  PARAMETERS:
///    *pValue - pointer for data
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CM_BSP_ETHERNET_GetNumberOfRxMessages (UWORD16 *pValue);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     IPC read message
///
///  PARAMETERS:
///    *pBuffer - pointer for read message
///    *pRxMessageLengh - pointer for read message length
///
///  RETURNS:
///    UWORD16 - number of messages
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_ReadMessage (UWORD8 *pBuffer, UWORD16 *pRxMessageLengh);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_Init (void);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP Create channel
///
///  PARAMETERS:
///    eChannel - channel number
///    *pParams - pointer for parameters
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_Create (CM_BSP_ETHERNET_Channel_E eChannel, CM_BSP_ETHERNET_Params_S *pParams);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP get info by channel
///
///  PARAMETERS:
///    eChannel - channel number
///
///  RETURNS:
///    CM_BSP_ETHERNET_Info_S *
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
CM_BSP_ETHERNET_Info_S *CM_BSP_ETHERNET_GetInfo (CM_BSP_ETHERNET_Channel_E eChannel);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP Open
///
///  PARAMETERS:
///    eChannel - Channel number
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_Open (CM_BSP_ETHERNET_Channel_E eChannel);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		Read data from ethernet
///
///  PARAMETERS:
///    *pBuffer - pointer for buffer to read data
///    lengthRead - length of data to be read
///    *pLengthRead - length read in channel
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_Read (UWORD8 *pBuffer, UWORD32 lengthRead, UWORD32 *pLengthRead);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		Write data to ethernet
///
///  PARAMETERS:
///    *pBuffer - pointer for buffer to read data
///    lengthWrite   - length of data to be write
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_Write (UWORD8 *pBuffer, UWORD32 lengthWrite);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     Set mac address
///
///  PARAMETERS:
///    UWORD32   - mac address
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_ETHERNET_SetMacAddrees (UWORD32 macAddress);

#endif /* __CM_BSP_ETHERNET_H__ */
