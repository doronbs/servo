
#include <CM_BSP_GeneralInclude.h>

uint32_t systickPeriodValue = 12500;//12500; //doronbs 10112023

void SysTickIntHandler(void)
{
    static long _SysTickIntHandler = 0;

    _SysTickIntHandler++;
    //
    // Call the lwIP timer handler.
    //
    lwIPTimer(systickPeriodValue);
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_TIMER_Init (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* system tick init */
    SYSTICK_setPeriod(systickPeriodValue);
    SYSTICK_enableCounter();
    SYSTICK_registerInterruptHandler(SysTickIntHandler);
    SYSTICK_enableInterrupt();

    return eReturnCode;
}
