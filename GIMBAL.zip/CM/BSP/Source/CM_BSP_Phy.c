
#include <CM_BSP_GeneralInclude.h>

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_PHY_Init (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     read from phy
///
///  PARAMETERS:
///    UWORD16    - address
///    UWORD16 *  - pointer for data
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_PHY_Read (UWORD16 address, UWORD16 *pData)
{
   /* check */
    if (pData == NULL)
    {
        /* error */
        return BSP_RETURN_POINTER_IS_NULL;
    }

    /* config phy address */
    Ethernet_configurePHYAddress (EMAC_BASE, CM_BSP_ETHERNET_PHY_ADDRESS);

    /* read */
    *pData = Ethernet_readPHYRegister (EMAC_BASE, address);

    return BSP_RETURN_SUCCESS;
}

