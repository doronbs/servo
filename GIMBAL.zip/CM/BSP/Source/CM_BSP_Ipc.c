
#include <CM_BSP_GeneralInclude.h>

CM_BSP_IPC_RxInfo_S g_cm_bsp_ipc_rx_info;
CM_BSP_IPC_TxInfo_S g_cm_bsp_ipc_tx_info;

#pragma DATA_SECTION(g_cm_bsp_ipc_tx_info, "MSGRAM_CM_TO_CPU1")

/* IPC ISR for Flag 0. C28x core sends data without message queue using Flag 0 */
__interrupt void IPC_ISR0()
{
    uint32_t command, rxDataAddress = 0, rxDataLength = 0;
    bool status = false;
    UWORD16 index = 0;
    static UWORD16 messageIndex = 0;

    static UWORD32 cm_ipc_msgCounter_rx_isr0 = 0;

    /* Read the command */
    IPC_readCommand (IPC_CM_L_CPU1_R, IPC_FLAG0, IPC_ADDR_CORRECTION_ENABLE, &command, &rxDataAddress, &rxDataLength);

    cm_ipc_msgCounter_rx_isr0++;

    //if (command == CM_BSP_IPC_CMD_READ_MEM)
    if (command == CM_BSP_IPC_CMD_WRITE)
    {
        status = true;

        /* read data */
        for (index = 0; index < rxDataLength; index++)
        {
            g_cm_bsp_ipc_rx_info.rxData[messageIndex][index] = (UWORD8)(*(uint32_t *) (rxDataAddress + (index << 1)));
        }

        /* set message length */
        g_cm_bsp_ipc_rx_info.rxDataLength[messageIndex] = rxDataLength;

        /* set number of messages */
        g_cm_bsp_ipc_rx_info.rxMessages = g_cm_bsp_ipc_rx_info.rxMessages < CM_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX ? g_cm_bsp_ipc_rx_info.rxMessages + 1 : g_cm_bsp_ipc_rx_info.rxMessages;

        /* set index */
        messageIndex = messageIndex < (CM_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX - 1) ? messageIndex + 1 : 0;

        //
        // Read and compare data
        //
        //for(i=0; i<data; i++)
        //{
        //    if(*((uint32_t *)addr + i) != i)
        //        status = false;
        //}
    }

    /* Send response to C28x core */
    if (status)
    {
        IPC_sendResponse (IPC_CM_L_CPU1_R, CM_BSP_IPC_SEND_RESPONSE_PASS);
    }
    else
    {
        IPC_sendResponse (IPC_CM_L_CPU1_R, CM_BSP_IPC_SEND_RESPONSE_FAILED);
    }

    /* Acknowledge the flag */
    IPC_ackFlagRtoL (IPC_CM_L_CPU1_R, IPC_FLAG0);
}

#if 0
/* IPC ISR for Flag 0. C28x core sends data without message queue using Flag 0 */
__interrupt void IPC_ISR0()
{
    int i;
    uint32_t command, addr, data;
    bool status = false;

    //
    // Read the command
    //
    IPC_readCommand(IPC_CM_L_CPU1_R, IPC_FLAG0, IPC_ADDR_CORRECTION_ENABLE, &command, &addr, &data);

    if(command == IPC_CMD_READ_MEM)
    {
        status = true;

        //
        // Read and compare data
        //
        for(i=0; i<data; i++)
        {
            if(*((uint32_t *)addr + i) != i)
                status = false;
        }
    }

    //
    // Send response to C28x core
    //
    if(status)
    {
        IPC_sendResponse(IPC_CM_L_CPU1_R, CM_BSP_IPC_SEND_RESPONSE_PASS);
    }
    else
    {
        IPC_sendResponse(IPC_CM_L_CPU1_R, CM_BSP_IPC_SEND_RESPONSE_FAILED);
    }

    //
    // Acknowledge the flag
    //
    IPC_ackFlagRtoL(IPC_CM_L_CPU1_R, IPC_FLAG0);

    /* set */
    isDataReady = TRUE;
}
#endif

#if 0
__interrupt void IPC_ISR0()
{
    int i;
    uint32_t command, addr, data;
    bool status = false;

    /* Read the command */
    IPC_readCommand(IPC_CM_L_CPU1_R, IPC_FLAG0, IPC_ADDR_CORRECTION_ENABLE, &command, &addr, &data);
    if(command == IPC_CMD_READ_MEM)
    {
        status = true;

        //
        // Read and compare data
        //
        for(i=0; i<data; i++)
        {
            if(*((uint32_t *)addr + i) != i)
                status = false;
        }
    }

    /* Send response to C28x core */
    if(status)
    {
        IPC_sendResponse(IPC_CM_L_CPU1_R, CM_BSP_IPC_SEND_RESPONSE_PASS);
    }
    else
    {
        IPC_sendResponse(IPC_CM_L_CPU1_R, CM_BSP_IPC_SEND_RESPONSE_FAILED);
    }

    /* Acknowledge the flag */
    IPC_ackFlagRtoL(IPC_CM_L_CPU1_R, IPC_FLAG0);
}
#endif
#if 0
__interrupt void IPC_ISR0()
{
    //uint32_t ipc_command;
    //uint32_t ipc_addr;
    //uint32_t IPC_data;
    static uint32_t counter_isr0 = 0;
    bool eReturnCode;



     /* read from ipc */
     //IPC_readCommand(IPC_CM_L_CPU1_R, IPC_FLAG5, IPC_ADDR_CORRECTION_ENABLE, &ipc_command, &ipc_addr, &IPC_data);



    flag_msg_arrived_from_c1 = true;
    eReturnCode = IPC_readCommand(IPC_CM_L_CPU1_R, IPC_FLAG5, IPC_ADDR_CORRECTION_ENABLE, &ipc_command, &ipc_addr, &IPC_data);


    if(eReturnCode == false)
    {
        /* error */
        //while (1);
        counter_isr0++;

    }
#if 1
    else
    {
        IPC_ackFlagRtoL(IPC_CM_L_CPU1_R, IPC_FLAG0);

        flag_msg_arrived_from_c1 = true;

        messageIpcLen = sizeof(messageIpc);

        memcpy(&messageIpc,&ipc_addr,IPC_data);


    }
#endif

}
#endif

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_IPC_Init (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;
    UWORD16 index = 0;

    /* Clear any IPC flags if set already */
    IPC_clearFlagLtoR (IPC_CM_L_CPU1_R, IPC_FLAG_ALL);

    /* Enable IPC interrupts */
    IPC_registerInterrupt (IPC_CM_L_CPU1_R, IPC_INT0, IPC_ISR0);

    /* Synchronize both the cores. */
    IPC_sync (IPC_CM_L_CPU1_R, IPC_FLAG31);

    /* clear */
    for (index = 0; index < CM_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX; index++)
    {
        g_cm_bsp_ipc_rx_info.rxDataLength[index] = 0;
    }

    /* clear */
    g_cm_bsp_ipc_rx_info.rxMessages = 0;

    return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     IPC get rx messages
///
///  PARAMETERS:
///    *pValue - pointer for data
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CM_BSP_IPC_GetNumberOfRxMessages (UWORD16 *pValue)
{
    if (pValue == NULL)
    {
        /* error */
        return;
    }

    /* set */
    *pValue = g_cm_bsp_ipc_rx_info.rxMessages;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     IPC read message
///
///  PARAMETERS:
///    *pBuffer - pointer for read message
///    *pLenghRead - pointer for read message length
///
///  RETURNS:
///    UWORD16 - number of messages
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_IPC_ReadMessage (UWORD8 *pBuffer, UWORD16 *pLenghRead)
{
    UWORD16 index = 0, rxMessages = 0;

    /* check */
    if ((pBuffer == NULL) || (pLenghRead == NULL))
    {
        /* error */
        return BSP_RETURN_POINTER_IS_NULL;
    }

    /* check */
    if ((*pLenghRead > CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX) || (*pLenghRead == 0))
    {
        /* error */
        return BSP_RETURN_LENGTH_IS_INVALID;
    }

    /* is messages in buffer? */
    CM_BSP_IPC_GetNumberOfRxMessages (&rxMessages);
    if (rxMessages == 0)
    {
        /* set */
        *pLenghRead = 0;

        /* error */
        return BSP_RETURN_IPC_RX_BUFFER_IS_EMPTY;
    }

    for (index = 0; index < CM_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX; index++)
    {
        if ((g_cm_bsp_ipc_rx_info.rxDataLength[index] > 0) && (g_cm_bsp_ipc_rx_info.rxDataLength[index] <= CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX))
        {
            /* copy data */
            memcpy (&pBuffer[0], &g_cm_bsp_ipc_rx_info.rxData[index][0], g_cm_bsp_ipc_rx_info.rxDataLength[index]);

            /* set length */
            *pLenghRead = g_cm_bsp_ipc_rx_info.rxDataLength[index];

            /* set number of message */
            if (g_cm_bsp_ipc_rx_info.rxMessages > 0)
            {
                g_cm_bsp_ipc_rx_info.rxMessages--;
            }

            /* clear length */
            g_cm_bsp_ipc_rx_info.rxDataLength[index] = 0;

            break;
        }
    }

    return BSP_RETURN_SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     IPC write message
///
///  PARAMETERS:
///    *pBuffer - pointer for write message
///    lengthWrite - message length
///
///  RETURNS:
///    UWORD16 - number of messages
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_IPC_WriteMessage (UWORD8 *pBuffer, UWORD32 lengthWrite)
{
    bool eReturnCode;
    UWORD16 index = 0;

    /* check */
    if (pBuffer == NULL)
    {
        /* error */
        return BSP_RETURN_POINTER_IS_NULL;
    }

    /* check */
    if (lengthWrite > CM_BSP_IPC_TX_MESSAGE_LENGTH_MAX)
    {
        /* error */
        return BSP_RETURN_SIZE_IS_OUT_OF_RANGE;
    }

    /* check */
    if (lengthWrite == 0)
    {
        /* error */
        return BSP_RETURN_SIZE_IS_ZERO;
    }

    /* copy data */
    for (index = 0; index < lengthWrite; index++)
    {
        g_cm_bsp_ipc_tx_info.txData[index] = pBuffer[index];
    }

    /* write to ipc */
    eReturnCode  = IPC_sendCommand(IPC_CM_L_CPU1_R, IPC_FLAG1, IPC_ADDR_CORRECTION_ENABLE, CM_BSP_IPC_CMD_WRITE, (uint32_t)&g_cm_bsp_ipc_tx_info.txData[0],  lengthWrite);
    if (eReturnCode == false)
    {
        /* error */
        return  BSP_RETURN_IPC_WRITE_FAILED;
    }

    /* Wait for acknowledgment TODO: maybe need to add timeout? */
    //IPC_waitForAck(IPC_CM_L_CPU1_R, IPC_FLAG1);

#if 0
    /* Read response */
    if (IPC_getResponse(IPC_CM_L_CPU1_R) != CM_BSP_IPC_SEND_RESPONSE_PASS)
    {
        /* error */
        return  BSP_RETURN_IPC_GET_RESPONSE_FAILED;
    }
#endif

    return BSP_RETURN_SUCCESS;
}



