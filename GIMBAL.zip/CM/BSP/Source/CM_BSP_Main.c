
#include <CM_BSP_GeneralInclude.h>

extern __interrupt void IPC_ISR0();

#define DEVICE_FLASH_WAITSTATES 2

// These are defined by the linker (see device linker command file)
extern uint16_t RamfuncsLoadStart;
extern uint16_t RamfuncsLoadSize;
extern uint16_t RamfuncsRunStart;
extern uint16_t constLoadStart;
extern uint16_t constLoadEnd;
extern uint16_t constLoadSize;
extern uint16_t constRunStart;
extern uint16_t constRunEnd;
extern uint16_t constRunSize;
uint32_t sendPacketFailedCount = 0;

//*****************************************************************************
//
// Called by lwIP Library. Could be used for periodic custom tasks.
//
//*****************************************************************************

uint32_t cnt_ms_lwip_Htimer=0;
uint32_t cnt_ms_TX_Htimer=0;
void lwIPHostTimerHandler(void)
{
//  msTime++;

    cnt_ms_lwip_Htimer++;
}

void CM_init(void)
{
    //
    // Disable the watchdog
    //
    SysCtl_disableWatchdog();

#ifdef _FLASH
    //
    // Copy time critical code and flash setup code to RAM. This includes the
    // following functions: InitFlash();
    //
    // The RamfuncsLoadStart, RamfuncsLoadSize, and RamfuncsRunStart symbols
    // are created by the linker. Refer to the device .cmd file.
    // Html pages are also being copied from flash to ram.
    //
    memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);
    memcpy(&constRunStart, &constLoadStart, (size_t)&constLoadSize);
    //
    // Call Flash Initialization to setup flash waitstates. This function must
    // reside in RAM.
    //
    Flash_initModule(FLASH0CTRL_BASE, FLASH0ECC_BASE, DEVICE_FLASH_WAITSTATES);
#endif

    //
    // Sets the NVIC vector table offset address.
    //
#ifdef _FLASH
    Interrupt_setVectorTableOffset((uint32_t)vectorTableFlash);
#else
    Interrupt_setVectorTableOffset((uint32_t)vectorTableRAM);
#endif

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP initialization
///
///  PARAMETERS:
///    None
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_BSP_MAIN_Init (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* Initializing the CM. Loading the required functions to SRAM. */
    CM_init();

    /* timer init */
    eReturnCode = CM_BSP_TIMER_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return eReturnCode;
    }

    /* Enable processor interrupts. */
    Interrupt_enableInProcessor();

    /* phy init */
    eReturnCode = CM_BSP_PHY_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return eReturnCode;
    }

    /* ipc init */
    eReturnCode = CM_BSP_IPC_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return eReturnCode;
    }

    /* ethernet init */
    eReturnCode = CM_BSP_ETHERNET_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return eReturnCode;
    }

	return eReturnCode;
}
