
#include <CM_BSP_GeneralInclude.h>

#define CM_UUT_MAIN_RUN_TEST

int main(void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* BSP main init*/
    eReturnCode = CM_BSP_MAIN_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* trap */
        while (1);
    }

    /* UUT */
#ifdef CM_UUT_MAIN_RUN_TEST
    //eReturnCode = CM_UUT_MAIN_Start (CM_UUT_MAIN_TEST_ETHERNET);
    eReturnCode = CM_UUT_MAIN_Start (CM_UUT_MAIN_TEST_IPC);

    while (TRUE);
#else
    /* FW */
    eReturnCode = CM_FW_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* trap */
        while (1);
    }
#endif
}
