
#include <CM_BSP_GeneralInclude.h>

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		Uart initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_UUT_ETHERNET_Init (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		Uart tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CM_UUT_ETHERNET_Test (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	eReturnCode = CM_UUT_ETHERNET_Init ();
	if (eReturnCode != BSP_RETURN_SUCCESS)
	{
		/* error */
		return;
	}

#if 1
	UWORD8 rxBuffer[CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX];
	UWORD32 lengthRead = 0;

    while (1)
    {
        eReturnCode = CM_BSP_ETHERNET_Read (rxBuffer, CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX, &lengthRead);
        if (eReturnCode == BSP_RETURN_SUCCESS)
        {
            /* send echo packet */
            CM_BSP_ETHERNET_Write (&rxBuffer[0], lengthRead);

        }

        SysCtl_delay(50000000);
    }
#endif


/* test to check receiving udp packets - only in callback function */
#if 0
	while (1)
	{
	    SysCtl_delay(50000000);
	}
#endif

#if 0
    UWORD8 message[CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX];
    UWORD32 index = 0;

    for (index = 0; index < CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX; index++)
    {
        message[index] = index;
    }

    while (1)
    {
        //eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &message[0], CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX);
        eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &message[0], 8);
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
           /* error */
           //while (1);
        }

        SysCtl_delay(50000);

    }
#endif

#if 0
    UWORD32 linkok = 0, linkerror = 0;
    CM_BSP_PHY_Address_0010_S status;

    while (1)
    {
        /* read status from phy */
        CM_BSP_PHY_Read (CM_BSP_PHY_STATUS_REGISTER, (UWORD16 *)&status);

        if (status.LinkStatus == CM_BSP_ETHERNET_LINK_STATUS_VALID_LINK_ESTABLISHED)
        {
            linkok++;
        }
        else
        {
            linkerror++;
        }

        SysCtl_delay(50000);
    }
#endif

#if 0
    static UWORD8 message[CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX];
    UWORD32 index = 0;
    //CM_BSP_PHY_Address_0010_S status;

    /* todo: need to wait startup time for ethernet stack, better to check if transmit is complete for each packet */
    SysCtl_delay(125000000);

    while (1)
    {
        for (index = 0; index < CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX; index++)
        {
            message[index] = index;
        }

        /* read status from phy */
        //CM_BSP_PHY_Read (CM_BSP_PHY_STATUS_REGISTER, (UWORD16 *)&status);

        //while (status.LinkStatus != CM_BSP_ETHERNET_LINK_STATUS_VALID_LINK_ESTABLISHED)
        //{
            /* read status from phy */
        //    CM_BSP_PHY_Read (CM_BSP_PHY_STATUS_REGISTER, (UWORD16 *)&status);

        //    SysCtl_delay(50000);
        //}

        for (index = 0; index < 10; index++)
        {
           //sizeMessage = sprintf (message, (char *) "Hello from application [%d]", counter++);
           eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &message[0], CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX);
           if (eReturnCode != BSP_RETURN_SUCCESS)
           {
               /* error */
               //while (1);
           }

           SysCtl_delay(50000);
        }

        while (1);
    }
#endif

#if 0
    while (1)
    {
        UWORD8 message[CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX];
        UWORD32 index = 0;
        CM_BSP_PHY_Address_0010_S status;

        /* read status from phy */
        CM_BSP_PHY_Read (CM_BSP_PHY_STATUS_REGISTER, (UWORD16 *)&status);

        for (index = 0; index < CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX; index++)
        {
            message[index] = index;
        }

        if (status.LinkStatus == CM_BSP_ETHERNET_LINK_STATUS_VALID_LINK_ESTABLISHED)
        {
           //sizeMessage = sprintf (message, (char *) "Hello from application [%d]", counter++);
           eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &message[0], CM_BSP_ETHERNET_TX_MESSAGE_LENGTH_MAX);
           if (eReturnCode != BSP_RETURN_SUCCESS)
           {
               /* error */
               while (1);
           }
        }

        SysCtl_delay(50000);
    }
#endif
}


