
#include <CM_BSP_GeneralInclude.h>

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		Uart initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_UUT_IPC_Init (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		Uart tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CM_UUT_IPC_Test (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	eReturnCode = CM_UUT_IPC_Init ();
	if (eReturnCode != BSP_RETURN_SUCCESS)
	{
		/* error */
		return;
	}


#if 1
    UWORD8 messageArrived[CM_BSP_ETHERNET_RX_MESSAGE_LENGTH_MAX];
    UWORD16 messageArrivedLen = CM_BSP_ETHERNET_RX_MESSAGE_LENGTH_MAX;
    UWORD16 rxMessages = 0;

    //********************echo*****************************

    UWORD8 rxBuffer[CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX];
    UWORD16 rxMessageLengh = CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX;
    UWORD32 errorCounter = 0, numberOfPackets = 0;

    //************************************************

    /* working with api without pragma (pragma is defined by swinfra team ) */
    while (1)
    {
        //eReturnCode = CM_BSP_IPC_WriteMessage (writeData, 10);//400//1500
        rxMessages = 0;
        CM_BSP_ETHERNET_GetNumberOfRxMessages (&rxMessages);
        if(rxMessages > 0)
        {
            eReturnCode = CM_BSP_ETHERNET_ReadMessage (messageArrived, &messageArrivedLen);
            if ((eReturnCode == BSP_RETURN_SUCCESS) && (messageArrivedLen > 0))
            {
                numberOfPackets++;

                /* send message via ipc */
                eReturnCode = CM_BSP_IPC_WriteMessage (messageArrived, messageArrivedLen);
                //eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &messageArrived[0], messageArrivedLen);
            }

            if (eReturnCode != BSP_RETURN_SUCCESS)
            {
                /* error */
                errorCounter++;
            }

            //DEVICE_DELAY_US(500000);
            //SysCtl_delay(50000);

        }

        //********************************echo**************************************
        CM_BSP_IPC_GetNumberOfRxMessages (&rxMessages);
        if (rxMessages > 0)
        {
            /* read message */
            eReturnCode = CM_BSP_IPC_ReadMessage (&rxBuffer[0], &rxMessageLengh);
            if ((eReturnCode == BSP_RETURN_SUCCESS) && (rxMessageLengh > 0))
            {
                /* send message via ethernet */
                eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &rxBuffer[0], rxMessageLengh);
                if (eReturnCode != BSP_RETURN_SUCCESS)
                {
                    /* trap */
                    while (1);
                }
            }
        }

        SysCtl_delay(50000);

     }
#endif

#if 0
	UWORD16 rxMessages = 0;
	UWORD8 rxBuffer[CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX];
	UWORD16 rxMessageLengh = CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX;

	while (1)
	{
	    rxMessages = 0;

	    CM_BSP_IPC_GetNumberOfRxMessages (&rxMessages);
	    if (rxMessages > 0)
	    {
	        /* set */
	        rxMessageLengh = CM_BSP_IPC_RX_MESSAGE_LENGTH_MAX;

	        /* read message */
	        eReturnCode = CM_BSP_IPC_ReadMessage (&rxBuffer[0], &rxMessageLengh);
	        if ((eReturnCode == BSP_RETURN_SUCCESS) && (rxMessageLengh > 0))
	        {
                /* send message via ethernet */
                eReturnCode = CM_BSP_ETHERNET_Write ((UWORD8 *) &rxBuffer[0], rxMessageLengh);
                if (eReturnCode != BSP_RETURN_SUCCESS)
                {
                    /* trap */
                    //while (1);
                }
	        }
	    }
	}
#endif

#if 0

	while (1)
	{
        if (isDataReady == TRUE)
        {

            /* Clear any IPC flags if set already */
            IPC_clearFlagLtoR (IPC_CM_L_CPU1_R, IPC_FLAG_ALL);

            /* Enable IPC interrupts */
            IPC_registerInterrupt (IPC_CM_L_CPU1_R, IPC_INT0, IPC_ISR0);

            /* Synchronize both the cores. */
            IPC_sync (IPC_CM_L_CPU1_R, IPC_FLAG31);

            /* reset */
            isDataReady = FALSE;
        }
	}

#endif
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///     Uart tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void CM_UUT_IPC_SEND_Test (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    eReturnCode = CM_UUT_IPC_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return;
    }

#if 0
    static UWORD8 writeData[10];//400//1500
    UWORD16 index = 0;

    for (index = 0; index < 10; index++)
    {
        writeData[index] = index;
    }

    /* working with api without pragma (pragma is defined by swinfra team ) */
    while (1)
    {
        eReturnCode = CM_BSP_IPC_WriteMessage (writeData, 10);//400//1500
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
            /* error */
            errorCounter++;
        }

        //DEVICE_DELAY_US(500000);
        SysCtl_delay(50000);
     }
#endif



#if 0
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    eReturnCode = C1_UUT_IPC_Init ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return;
    }


    //UWORD8 writeData[C1_BSP_IPC_MESSAGE_MAX];
    UWORD16 index = 0;
    UWORD32 errorCounter = 0;
    UWORD8 txBuffer[100];
    UWORD32 txBufferLength = 0;

    for (index = 0; index < C1_BSP_IPC_MESSAGE_MAX; index++)
    {
        __byte(writeData, 0)  = 0;
        __byte(writeData, 1)  = 1;
        __byte(writeData, 2)  = 2;
        __byte(writeData, 3)  = 3;
        __byte(writeData, 1400)  = 0x1234;

        txBufferLength = sprintf (writeData, "Buffer ---> %d\r\n", writeData[index]);

        C1_BSP_Uart_Write (&writeData[0], txBufferLength);
    }




    while (1)
    {
        eReturnCode = C1_BSP_IPC_Write (&writeData[0], C1_BSP_IPC_MESSAGE_MAX);
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
            /* error */
            errorCounter++;
        }

        DEVICE_DELAY_US(500000);
    }
#endif

}
