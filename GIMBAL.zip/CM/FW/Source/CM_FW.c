
#include <CM_BSP_GeneralInclude.h>

CM_FW_Info_S g_cw_fw_info;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///		BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_FW_Init (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* set state */
    g_cw_fw_info.eState = CM_FW_STATE_NOT_STARTED;

    /* run main state machine */
    eReturnCode = CM_FW_Run ();
    if (eReturnCode != BSP_RETURN_SUCCESS)
    {
        /* error */
        return eReturnCode;
    }

	return BSP_RETURN_SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     FW run
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E CM_FW_Run (void)
{
    //BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* main state machine */
    switch (g_cw_fw_info.eState)
    {
        case CM_FW_STATE_NOT_STARTED:
            break;

        case CM_FW_STATE_WAIT_FOR_UDP_PACKET:
            break;

        case CM_FW_STATE_READ_UDP_PACKET:
            break;

        case CM_FW_STATE_SEND_UDP_PACKET:
            break;

        case CM_FW_STATE_READ_IPC_PACKET:
            /* set state */
            g_cw_fw_info.eState = CM_FW_STATE_SEND_UDP_PACKET;
            break;

        case CM_FW_STATE_SEND_IPC_PACKET:
            break;

        default:
            /* error*/
            return BSP_RETURN_SWITCH_CASE_IS_INVALID;
    }

    return BSP_RETURN_SWITCH_CASE_IS_INVALID;
}

