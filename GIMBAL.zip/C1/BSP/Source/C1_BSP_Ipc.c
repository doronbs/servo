
#include "C1_BSP_GeneralInclude.h"

#pragma DATA_SECTION(g_c1_bsp_ipc_info, "MSGRAM_CPU_TO_CM")

C1_BSP_IPC_Info_S g_c1_bsp_ipc_info;

//#pragma DATA_SECTION(g_c1_bsp_ipc_rx_info, "MSGRAM_CM_TO_CPU")
C1_BSP_IPC_RxInfo_S g_c1_bsp_ipc_rx_info;

__interrupt void IPC_ISR1()
{

    uint32_t command, rxAddressData, dataLength;
    bool status = false;
    bool eReturnCode;


    //UWORD8 messageIpcTest[10];
    UWORD16 index;
    static WORD16 messageIndex = 0;

    UWORD16 shortT = 0;
    UWORD8 byte1 = 0;
    UWORD8 byte2 = 0;
    UWORD16 bytesIdx = 0;
    UWORD16 dataLenMax = 0;

    static UWORD32 c1_counter_ipc_isr1_msgs = 0;
    //
    // Read the command
    //
    eReturnCode = IPC_readCommand(IPC_CPU1_L_CM_R, IPC_FLAG1, IPC_ADDR_CORRECTION_ENABLE, &command, &rxAddressData, &dataLength);
    c1_counter_ipc_isr1_msgs ++;

    if (eReturnCode == false)
    {
        /* error */
        return;
    }

    if(command == C1_BSP_IPC_CMD_READ_MEM)
    {
        status = true;

#if 0
        UWORD16 index = 0;
        // for test only
        //
        // Read and compare data
        //
        for(i=0; i<data; i++)
        {
            if(*((uint32_t *)addr + i) != i)
            {
                status = false;
            }

        }
#endif
    }

    //
    // Send response to C28x core
    //

    if(status)
    {

        IPC_sendResponse(IPC_CPU1_L_CM_R, C1_BSP_IPC_SEND_RESPONSE_PASS);
#if 0
        /* copy data */
        for (index = 0 ; index < dataLength; index++)
        {
            messageIpcTest[index] = (UWORD8) (*((UWORD8 *)rxAddressData + index));//(index << 1)));
            //messageIpc[index] = (UWORD8) (*((UWORD8 *)rxAddressData + (index << 1)));//libi

        }

        //messageEthLen = dataLength;//libi
        //flag_msg_arrived_from_c1 = true;//libi
#endif

        /* read data : in each loop reading one byte up to max length*/
        bytesIdx = 0;

        if(dataLength% 2 == 0)
           dataLenMax = dataLength/2;
        else
           dataLenMax = dataLength/2 + 1;

        for (index = 0; index < dataLenMax; index++)
        {
            //g_c1_bsp_ipc_rx_info.rxData[messageIndex][index] = (UWORD8) (*((UWORD8 *)rxAddressData + index));//(UWORD8)(*(uint32_t *) (rxDataAddress + (index << 1)));

            shortT = (*((UWORD16 *)rxAddressData + index));
            byte1 = shortT & 0xFF;
            shortT = (shortT >> 8);
            byte2 = shortT & 0xFF;

            g_c1_bsp_ipc_rx_info.rxData[messageIndex][bytesIdx] = (UWORD8)byte1;
            bytesIdx = bytesIdx + 1;
            g_c1_bsp_ipc_rx_info.rxData[messageIndex][bytesIdx] = (UWORD8)byte2;
            bytesIdx = bytesIdx + 1;
        }

        /* set message length */
        g_c1_bsp_ipc_rx_info.rxDataLength[messageIndex] = dataLength;

        /* set number of messages */
        if (g_c1_bsp_ipc_rx_info.rxMessages < C1_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX)
        {
           g_c1_bsp_ipc_rx_info.rxMessages++;
        }

        /* set index */
        if (messageIndex < (C1_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX - 1))
        {
           messageIndex++;
        }
        else
        {
           messageIndex = 0;
        }
    }
    else
    {
        IPC_sendResponse(IPC_CPU1_L_CM_R, C1_BSP_IPC_SEND_RESPONSE_FAILED);
    }

    //
    // Acknowledge the flag
    //
    IPC_ackFlagRtoL(IPC_CPU1_L_CM_R, IPC_FLAG1);

    //BSP_IPC_Read ();
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP11);
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_BSP_IPC_Init (void)
{
      BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

      //initialize
      memset(g_c1_bsp_ipc_rx_info.rxData,0 ,sizeof(g_c1_bsp_ipc_rx_info.rxData));
      memset(g_c1_bsp_ipc_rx_info.rxDataLength,0,sizeof(g_c1_bsp_ipc_rx_info.rxDataLength));
      g_c1_bsp_ipc_rx_info.rxMessages = 0;

      g_c1_bsp_ipc_info.totaltxMsgsSent = 0;
      g_c1_bsp_ipc_info.txDataLength = 0;
      memset(g_c1_bsp_ipc_info.txData,0,sizeof(g_c1_bsp_ipc_info.txData));
      //
      // Initialize PIE and clear PIE registers. Disables CPU interrupts.
      //
      Interrupt_initModule();

      //
      // Initialize the PIE vector table with pointers to the shell Interrupt
      // Service Routines (ISR).
      //
      Interrupt_initVectorTable();

      //
      // Clear any IPC flags if set already
      //
      IPC_clearFlagLtoR(IPC_CPU1_L_CM_R, IPC_FLAG_ALL);

      //
      // Synchronize both the cores.
      //

      //
     // Enable IPC interrupts
     //
      IPC_registerInterrupt(IPC_CPU1_L_CM_R, IPC_INT1, IPC_ISR1);//libi
     //

      IPC_sync(IPC_CPU1_L_CM_R, IPC_FLAG31);

      //
      // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
      //
      EINT;
      ERTM;

      return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     Write ipc data from C1 to CM
///
///  PARAMETERS:
///    *pBuffer - pointer for buffer to read data
///    lengthWrite   - length of data to be write
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_BSP_IPC_Write (UWORD8 *pBuffer, UWORD32 lengthWrite)
{
    bool eReturnCode;
    UWORD16 index = 0;

    static UWORD32 c1_ipc_errorCounter = 0;


    /* check */
    if (pBuffer == NULL)
    {
        /* error */
        return BSP_RETURN_POINTER_IS_NULL;
    }

    /* check */
    if (lengthWrite > C1_BSP_IPC_MESSAGE_MAX)
    {
        /* error */
        return BSP_RETURN_SIZE_IS_OUT_OF_RANGE;
    }

    /* check */
    if (lengthWrite == 0)
    {
        /* error */
        return BSP_RETURN_SIZE_IS_ZERO;
    }

    /* copy data */
    for (index = 0; index < lengthWrite; index++)
    {
        g_c1_bsp_ipc_info.txData[index] = pBuffer[index];
    }

    /* write to ipc */
    eReturnCode  = IPC_sendCommand(IPC_CPU1_L_CM_R, IPC_FLAG0, IPC_ADDR_CORRECTION_ENABLE, C1_BSP_IPC_CMD_READ_MEM, (uint32_t)&g_c1_bsp_ipc_info.txData[0],  lengthWrite);
    if (eReturnCode == false)
    {
        c1_ipc_errorCounter++;

        /* error */
        return  BSP_RETURN_IPC_WRITE_FAILED;
    }
#if 1
    /* Wait for acknowledgment TODO: maybe need to add timeout? */
    IPC_waitForAck(IPC_CPU1_L_CM_R, IPC_FLAG0);

#if 1
    /* Read response */
    uint32_t response = 0;

    response = IPC_getResponse(IPC_CPU1_L_CM_R);

    //if (IPC_getResponse(IPC_CPU1_L_CM_R) != C1_BSP_IPC_SEND_RESPONSE_PASS)
    if (response != C1_BSP_IPC_SEND_RESPONSE_PASS)
    {
        c1_ipc_errorCounter++;

        /* error */
        return  BSP_RETURN_IPC_GET_RESPONSE_FAILED;
    }
#endif

#endif

    return BSP_RETURN_SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     Write ipc data from C1 to CM
///
///  PARAMETERS:
///    *pBuffer - pointer for buffer to read data
///    lengthWrite   - length of data to be write
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void C1_BSP_IPC_GetNumberOfRxMessages (UWORD16 *pValue)
{

    if (pValue == NULL)
    {
        /* error */
        return;
    }

    /* set */
    *pValue = g_c1_bsp_ipc_rx_info.rxMessages;

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     Write ipc data from C1 to CM
///
///  PARAMETERS:
///    *pBuffer - pointer for buffer to read data
///    lengthWrite   - length of data to be write
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_BSP_IPC_ReadMessage (UWORD8 *pBuffer, UWORD16 *pRxMessageLengh)
{

    UWORD16 index = 0;
    UWORD16 rxMessages = 0;

    /* check */
    if ((pBuffer == NULL) || (pRxMessageLengh == NULL))
    {
        /* error */
        return BSP_RETURN_POINTER_IS_NULL;
    }
#if 1
    /* check */
    if ((*pRxMessageLengh > C1_BSP_IPC_RX_MESSAGE_LENGTH_MAX) || (*pRxMessageLengh == 0))
    {
        /* error */
        return BSP_RETURN_LENGTH_IS_INVALID;
    }
#endif

    /* are there messages inside the buffer or its empty? */
    C1_BSP_IPC_GetNumberOfRxMessages(&rxMessages);

    if (rxMessages == 0)
    {
        /* set */
        *pRxMessageLengh = 0;

        /* error */
        return BSP_RETURN_IPC_RX_BUFFER_IS_EMPTY;
    }


    for (index = 0; index < C1_BSP_IPC_RX_NUMBER_OF_MESSAGES_MAX; index++)
    {
        if((g_c1_bsp_ipc_rx_info.rxDataLength[index] > 0) && (g_c1_bsp_ipc_rx_info.rxDataLength[index] <= C1_BSP_IPC_RX_MESSAGE_LENGTH_MAX))
        {
            /* copy data */
            memcpy (&pBuffer[0], &g_c1_bsp_ipc_rx_info.rxData[index][0], g_c1_bsp_ipc_rx_info.rxDataLength[index]);

            /* set length */
            *pRxMessageLengh = g_c1_bsp_ipc_rx_info.rxDataLength[index];

            /* set number of message */
            g_c1_bsp_ipc_rx_info.rxMessages--;

            /* clear length */
            g_c1_bsp_ipc_rx_info.rxDataLength[index] = 0;

        }

    }

    return BSP_RETURN_SUCCESS;











}


