
#include "C1_BSP_GeneralInclude.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP_LED initialization
///
///  PARAMETERS:
///    None
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E BSP_LED_Init (void)
{
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* for evaluation board only ---> LED1 */
    GPIO_setPadConfig(DEVICE_GPIO_PIN_LED1, GPIO_PIN_TYPE_STD);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_LED1, GPIO_DIR_MODE_OUT);

    /* for evaluation board only ---> LED2 */
    GPIO_setPadConfig(DEVICE_GPIO_PIN_LED2, GPIO_PIN_TYPE_STD);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_LED2, GPIO_DIR_MODE_OUT);

    GPIO_setControllerCore(DEVICE_GPIO_PIN_LED1, GPIO_CORE_CPU1);
    GPIO_setControllerCore(DEVICE_GPIO_PIN_LED2, GPIO_CORE_CPU1);
    return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP_LED toggle pin value
///
///  PARAMETERS:
///   eChannel - pin number
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E BSP_LED_Toggle (BSP_LED_Channel_E eChannel)
{
    static char val[BSP_LED_CHANNEL_MAX];
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* check */
    if (eChannel >= BSP_LED_CHANNEL_MAX)
    {
        /* error */
        return BSP_RETURN_CHANNEL_IS_INVALID;
    }

    /* toggle */
    val[eChannel] ^=1;
    if(eChannel==BSP_LED_CHANNEL_0)
        GPIO_writePin(DEVICE_GPIO_PIN_LED1, val[eChannel]);
    else if(eChannel==BSP_LED_CHANNEL_1)
        GPIO_writePin(DEVICE_GPIO_PIN_LED2, val[eChannel]);

    return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP_LED set pin value
///
///  PARAMETERS:
///   eChannel - pin number
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E BSP_LED_SetLevel (BSP_LED_Channel_E eChannel, BSP_LED_Level_E eLevel)
{
    static char val[BSP_LED_CHANNEL_MAX];
    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

    /* check */
    if (eChannel >= BSP_LED_CHANNEL_MAX)
    {
        /* error */
        return BSP_RETURN_CHANNEL_IS_INVALID;
    }

    val[eChannel] = eLevel & 0x01;
    if(eChannel==BSP_LED_CHANNEL_0)
        GPIO_writePin(DEVICE_GPIO_PIN_LED1, val[eChannel]);
    else if(eChannel==BSP_LED_CHANNEL_1)
        GPIO_writePin(DEVICE_GPIO_PIN_LED2, val[eChannel]);

    return eReturnCode;
}




