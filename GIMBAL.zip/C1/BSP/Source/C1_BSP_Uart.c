
#include "C1_BSP_GeneralInclude.h"

C1_BSP_UART_Info_S g_c1_bsp_uart_info;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_BSP_UART_Init (void)
{

    BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;
    //
    // GPIO28 is the SCI Rx pin.
    //
    GPIO_setControllerCore(DEVICE_GPIO_PIN_SCIRXDA, GPIO_CORE_CPU1);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_SCIRXDA);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_SCIRXDA, GPIO_DIR_MODE_IN);
    GPIO_setPadConfig(DEVICE_GPIO_PIN_SCIRXDA, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(DEVICE_GPIO_PIN_SCIRXDA, GPIO_QUAL_ASYNC);

    //
    // GPIO29 is the SCI Tx pin.
    //
    GPIO_setControllerCore(DEVICE_GPIO_PIN_SCITXDA, GPIO_CORE_CPU1);
    GPIO_setPinConfig(DEVICE_GPIO_CFG_SCITXDA);
    GPIO_setDirectionMode(DEVICE_GPIO_PIN_SCITXDA, GPIO_DIR_MODE_OUT);
    GPIO_setPadConfig(DEVICE_GPIO_PIN_SCITXDA, GPIO_PIN_TYPE_STD);
    GPIO_setQualificationMode(DEVICE_GPIO_PIN_SCITXDA, GPIO_QUAL_ASYNC);

    //
    // Initialize SCIA and its FIFO.
    //
    SCI_performSoftwareReset(SCIA_BASE);

    //
    // Configure SCIA for echoback.
    //
    SCI_setConfig(SCIA_BASE, DEVICE_LSPCLK_FREQ, 460800, (SCI_CONFIG_WLEN_8 | SCI_CONFIG_STOP_ONE | SCI_CONFIG_PAR_NONE));
    SCI_resetChannels(SCIA_BASE);
    SCI_resetRxFIFO(SCIA_BASE);
    SCI_resetTxFIFO(SCIA_BASE);
    SCI_clearInterruptStatus(SCIA_BASE, SCI_INT_TXFF | SCI_INT_RXFF);
    SCI_enableFIFO(SCIA_BASE);
    SCI_enableModule(SCIA_BASE);
    SCI_performSoftwareReset(SCIA_BASE);


    //
    // Interrupts that are used in this example are re-mapped to
    // ISR functions found within this file.
    //
    //Interrupt_register(INT_SCIA_RX, sciaRxISR);
    //Interrupt_register(INT_SCIA_TX, sciaTxISR);


    //in_buf_indx_in_uart = 0;
    //in_buf_indx_out_uart =0;
    //out_buf_indx_in_uart =0;
    //out_buf_indx_out_uart = 0;
    //
    // Initialize the Device Peripherals:
    //



    Interrupt_enable(INT_SCIA_RX);
    Interrupt_enable(INT_SCIA_TX);

    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP9);

    return eReturnCode;

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $BSP_FUNCTIONS>
///  DESCRIPTION:
///     BSP initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_BSP_UART_Write (UWORD8 *pBuffer, UWORD32 lengthWrite)
{
    UWORD32 idx = 0;

    /* check */
    if (pBuffer == NULL)
    {
        /* error */
        return BSP_RETURN_POINTER_IS_NULL;
    }

    /* check */
    if (lengthWrite > C1_BSP_UART_MESSAGE_MAX)
    {
        /* error */
        return BSP_RETURN_SIZE_IS_OUT_OF_RANGE;
    }

    /* check */
    if (lengthWrite == 0)
    {
        /* error */
        return BSP_RETURN_SIZE_IS_ZERO;
    }

    /* copy data */
    //for(idx = 0; idx < lengthWrite ; idx++)
    //{
    //    g_c1_bsp_uart_info.txData[idx] = pBuffer[idx];
    //}

#if 1
    for (idx = 0; idx < lengthWrite; idx++)
    {
        SCI_writeCharBlockingNonFIFO (SCIA_BASE, pBuffer[idx]);
        //while (SciaRegs.SCIFFTX.bit.TXFFST != 0) {}
        //SciaRegs.SCITXBUF.all = pBuffer[idx];
    }

#else

    for (idx = 0; idx < lengthWrite; idx++)
    {
        if (SCI_getTxFIFOStatus(SCIA_BASE) <= SCI_FIFO_TX16)
        {
            //HWREGH(SCIA_BASE + SCI_O_TXBUF) = (uint16_t)buff_uart_output[idx] & SCI_RXBUF_SAR_M;
            HWREGH(SCIA_BASE + SCI_O_TXBUF) = (uint16_t)g_c1_bsp_uart_info.txData[idx] & SCI_RXBUF_SAR_M;

            /* mask */
            idx &= SCI_RXBUF_SAR_M;
        }
    }
#endif
    return BSP_RETURN_SUCCESS;
}
