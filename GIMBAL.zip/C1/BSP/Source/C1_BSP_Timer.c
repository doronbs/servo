
#include "C1_BSP_GeneralInclude.h"

BSP_TIMER_Info_S g_bsp_timer_info;

BSP_Return_E BSP_TIMER_Init (BSP_TIMER_Channel_E eChannel)
{
    switch (eChannel)
    {
        case BSP_TIMER_CHANNEL_0:
            Interrupt_register(INT_TIMER0, &BSP_TIMER_ISR0);
            CPUTimer_setPeriod(CPUTIMER0_BASE, 0xFFFFFFFF);
            CPUTimer_setPreScaler(CPUTIMER0_BASE, 0);
            CPUTimer_stopTimer(CPUTIMER0_BASE);
            CPUTimer_reloadTimerCounter(CPUTIMER0_BASE);
            g_bsp_timer_info.counter[0] = 0;
            break;

        case BSP_TIMER_CHANNEL_1:
            Interrupt_register(INT_TIMER1, &BSP_TIMER_ISR1);
            CPUTimer_setPeriod(CPUTIMER1_BASE, 0xFFFFFFFF);
            CPUTimer_setPreScaler(CPUTIMER1_BASE, 0);
            CPUTimer_stopTimer(CPUTIMER1_BASE);
            CPUTimer_reloadTimerCounter(CPUTIMER1_BASE);
            g_bsp_timer_info.counter[1] = 0;
            break;

        case BSP_TIMER_CHANNEL_2:
            Interrupt_register(INT_TIMER2, &BSP_TIMER_ISR2);
            CPUTimer_setPeriod(CPUTIMER2_BASE, 0xFFFFFFFF);
            CPUTimer_setPreScaler(CPUTIMER2_BASE, 0);
            CPUTimer_stopTimer(CPUTIMER2_BASE);
            CPUTimer_reloadTimerCounter(CPUTIMER2_BASE);
            g_bsp_timer_info.counter[2] = 0;
            break;

        default:
            /* error*/
            return BSP_RETURN_UNDEFINED_CASE;
    }

    return BSP_RETURN_SUCCESS;
}

BSP_Return_E BSP_TIMER_Start (BSP_TIMER_Channel_E eChannel, g_CallbackFunc cbFunc, uint32_t cycleMicroSec)
{
    switch (eChannel)
    {
        case BSP_TIMER_CHANNEL_0:
            g_bsp_timer_info.cbFunc[0] = cbFunc;
            BSP_TIMER_Config(CPUTIMER0_BASE, DEVICE_SYSCLK_FREQ, cycleMicroSec);
            CPUTimer_enableInterrupt(CPUTIMER0_BASE);
            Interrupt_enable(INT_TIMER0);
            CPUTimer_startTimer(CPUTIMER0_BASE);
            break;

        case BSP_TIMER_CHANNEL_1:
            g_bsp_timer_info.cbFunc[1] = cbFunc;
            BSP_TIMER_Config(CPUTIMER1_BASE, DEVICE_SYSCLK_FREQ, cycleMicroSec);
            CPUTimer_enableInterrupt(CPUTIMER1_BASE);
            Interrupt_enable(INT_TIMER1);
            CPUTimer_startTimer(CPUTIMER1_BASE);
            break;

        case BSP_TIMER_CHANNEL_2:
            g_bsp_timer_info.cbFunc[2] = cbFunc;
            BSP_TIMER_Config(CPUTIMER2_BASE, DEVICE_SYSCLK_FREQ, cycleMicroSec);
            CPUTimer_enableInterrupt(CPUTIMER2_BASE);
            Interrupt_enable(INT_TIMER2);
            CPUTimer_startTimer(CPUTIMER2_BASE);
            break;

        default:
            /* error*/
            return BSP_RETURN_UNDEFINED_CASE;
    }

    return BSP_RETURN_SUCCESS;
}

BSP_Return_E BSP_TIMER_Stop (BSP_TIMER_Channel_E eChannel)
{
    switch(eChannel)
    {

        case BSP_TIMER_CHANNEL_0:
            CPUTimer_stopTimer(CPUTIMER0_BASE);
            break;

        case BSP_TIMER_CHANNEL_1:
            CPUTimer_stopTimer(CPUTIMER1_BASE);
            break;

        case BSP_TIMER_CHANNEL_2:
            CPUTimer_stopTimer(CPUTIMER2_BASE);
            break;

        default:
            /* error*/
            return BSP_RETURN_UNDEFINED_CASE;
    }

    return BSP_RETURN_SUCCESS;
}

void BSP_TIMER_Config (uint32_t cpuTimer, float freq, float period)
{
    uint32_t temp = 0;

    //
    // Initialize timer period:
    //
    temp = (uint32_t)((freq / 1000000) * period);
    CPUTimer_setPeriod(cpuTimer, temp);

    //
    // Set pre-scale counter to divide by 1 (SYSCLKOUT):
    //
    CPUTimer_setPreScaler(cpuTimer, 0);

    //
    // Initializes timer control register. The timer is stopped, reloaded,
    // free run disabled, and interrupt enabled.
    // Additionally, the free and soft bits are set
    //
    CPUTimer_stopTimer(cpuTimer);
    CPUTimer_reloadTimerCounter(cpuTimer);
    CPUTimer_setEmulationMode(cpuTimer,
                              CPUTIMER_EMULATIONMODE_STOPAFTERNEXTDECREMENT);
    CPUTimer_enableInterrupt(cpuTimer);

    //
    // Resets interrupt counters for the three cpuTimers
    //
    if (cpuTimer == CPUTIMER0_BASE)
    {
        g_bsp_timer_info.counter[0] = 0;
    }
    else if(cpuTimer == CPUTIMER1_BASE)
    {
        g_bsp_timer_info.counter[1] = 0;
    }
    else if(cpuTimer == CPUTIMER2_BASE)
    {
        g_bsp_timer_info.counter[2] = 0;
    }
}

__interrupt void BSP_TIMER_ISR0(void)
{
    g_bsp_timer_info.counter[0]++;
    //if(tim_funk0 !=NULL)
    //    tim_funk0();

    if (g_bsp_timer_info.cbFunc[0] != NULL)
    {
        /* run callback */
        g_bsp_timer_info.cbFunc[0]();
    }

    //
    // Acknowledge this interrupt to receive more interrupts from group 1
    //
    Interrupt_clearACKGroup(INTERRUPT_ACK_GROUP1);
}

__interrupt void BSP_TIMER_ISR1(void)
{
    //
    // The CPU acknowledges the interrupt.
    //
    g_bsp_timer_info.counter[1]++;
    //if(tim_funk1 !=NULL)
    //    tim_funk1();

    if (g_bsp_timer_info.cbFunc[1] != NULL)
    {
        /* run callback */
        g_bsp_timer_info.cbFunc[1]();
    }

}

__interrupt void BSP_TIMER_ISR2(void)
{
    //
    // The CPU acknowledges the interrupt.
    //
    g_bsp_timer_info.counter[2]++;
    //if(tim_funk2 !=NULL)
    //    tim_funk2();

    if (g_bsp_timer_info.cbFunc[2] != NULL)
    {
        /* run callback */
        g_bsp_timer_info.cbFunc[2]();
    }

}
