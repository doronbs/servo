
#include "C1_BSP_GeneralInclude.h"

#if 0
uint32_t UUT_TIMER_TSC(void)
{
    uint32_t l_val,h_val;
    l_val = HWREG(IPCCOUNTERL);

    return(l_val);
}
#endif
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		UUT_TIMER initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E UUT_TIMER_Init (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		UUT_TIMER tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static char timer_stop_flag,timer_restart_flag;
void UUT_TIMER_Callback_0 (void)
{
    static uint64_t ts_c[3];
    static int val=0;
    static float delta0 = 0;
    ts_c[val] = IPC_getCounter(IPC_CPU1_L_CM_R);
    ts_c[2] = val==1 ? ts_c[1]-ts_c[0] : ts_c[0]-ts_c[1];
    delta0 = (1000000.0*ts_c[2]) / DEVICE_SYSCLK_FREQ;
    val ^=1;
//    GPIO_writePin(DEVICE_GPIO_PIN_LED1, val);
//    BSP_LED_Toggle(BSP_LED_CHANNEL_0);
    BSP_LED_SetLevel(BSP_LED_CHANNEL_0,val==0 ? BSP_LED_LEVEL_LOW : BSP_LED_LEVEL_HIGH);
    /* for warning removal only */
    delta0 = delta0;
    if(timer_stop_flag) {
//        timer_stop_flag=0;
//        BSP_TIMER_Stop(BSP_TIMER_CHANNEL_0);
    }
    if(timer_restart_flag) {
        timer_restart_flag=0;
//        BSP_TIMER_Start (BSP_TIMER_CHANNEL_1, UUT_TIMER_Callback_1,   5000);
        BSP_TIMER_Start (BSP_TIMER_CHANNEL_2, UUT_TIMER_Callback_2,   1000);
    }

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///     UUT_TIMER tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void UUT_TIMER_Callback_1 (void)
{
    static uint64_t ts_c[3];
    static int val=0;
    static float delta1;
    ts_c[val] = IPC_getCounter(IPC_CPU1_L_CM_R);
    ts_c[2] = val==1 ? ts_c[1]-ts_c[0] : ts_c[0]-ts_c[1];
    delta1 = (1000000.0*ts_c[2]) / DEVICE_SYSCLK_FREQ;
    val ^=1;
//    GPIO_writePin(DEVICE_GPIO_PIN_LED2, val);
    BSP_LED_Toggle(BSP_LED_CHANNEL_1);

    /* for warning removal only */
    delta1 = delta1;
    if(timer_stop_flag) {
//        timer_stop_flag=0;
//        BSP_TIMER_Stop(BSP_TIMER_CHANNEL_1);
    }
    if(timer_restart_flag) {
//        timer_restart_flag=0;
//        BSP_TIMER_Start (BSP_TIMER_CHANNEL_0, UUT_TIMER_Callback_0,  10000);
//        BSP_TIMER_Start (BSP_TIMER_CHANNEL_2, UUT_TIMER_Callback_2,   1000);
    }


    //BSP_LED_Toggle (BSP_LED_CHANNEL_0);

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///     UUT_TIMER tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void UUT_TIMER_Callback_2 (void)
{
    static uint64_t ts_c[3];
    static int val=0;
    static float delta2;
    ts_c[val] = IPC_getCounter(IPC_CPU1_L_CM_R);
    ts_c[2] = val==1 ? ts_c[1]-ts_c[0] : ts_c[0]-ts_c[1];
    delta2 = (1000000.0*ts_c[2]) / DEVICE_SYSCLK_FREQ;
    val ^=1;
//    GPIO_writePin(39, val);
    BSP_GPIO_TogglePInLevel(BSP_GPIO_CHANNEL_3);

    /* for warning removal only */
    delta2 = delta2;
    if(timer_stop_flag) {
        timer_stop_flag=0;
        BSP_TIMER_Stop(BSP_TIMER_CHANNEL_2);
    }
    if(timer_restart_flag) {
//        timer_restart_flag=0;
//        BSP_TIMER_Start (BSP_TIMER_CHANNEL_0, UUT_TIMER_Callback_0,  10000);
//        BSP_TIMER_Start (BSP_TIMER_CHANNEL_1, UUT_TIMER_Callback_1,   5000);
    }

    //BSP_LED_Toggle (BSP_LED_CHANNEL_0);

}

void C1_UUT_TIMER_Test (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;
    GPIO_setControllerCore(39, GPIO_CORE_CPU1);
    GPIO_setPadConfig(39, GPIO_PIN_TYPE_STD);
    GPIO_setDirectionMode(39, GPIO_DIR_MODE_OUT);
	
	eReturnCode = UUT_TIMER_Init ();
	if (eReturnCode != BSP_RETURN_SUCCESS)
	{
		/* error */
		return;
	}

#if 1
    /* set continuous callback timer function for 100us */
//	BSP_TIMER_Start (BSP_TIMER_CHANNEL_0, g_CallbackFunc cbFunc, UWORD32 cycleMicroSec);

	BSP_TIMER_Start (BSP_TIMER_CHANNEL_0, UUT_TIMER_Callback_0,  10000);
	BSP_TIMER_Start (BSP_TIMER_CHANNEL_1, UUT_TIMER_Callback_1,   5000);
	BSP_TIMER_Start (BSP_TIMER_CHANNEL_2, UUT_TIMER_Callback_2,   1000);

#endif
}


