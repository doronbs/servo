
#include "C1_UUT_Main.h"

extern C1_BSP_IPC_Info_S g_c1_bsp_ipc_info;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		Uart initialization
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_UUT_IPC_Init (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	return eReturnCode;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		Uart tests
///
///  PARAMETERS:
///    NONE
///
///  RETURNS:
///    None
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void C1_UUT_IPC_Test (void)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;
	
	eReturnCode = C1_UUT_IPC_Init ();
	if (eReturnCode != BSP_RETURN_SUCCESS)
	{
		/* error */
		return;
	}

#if 1
    UWORD8 writeData[C1_BSP_IPC_MESSAGE_MAX], index = 0;

    static UWORD32 c1_ipc_msgCounterOk_tx = 0, c1_ipc_msgCounterError_tx = 0 ;

    for (index = 0; index < C1_BSP_IPC_MESSAGE_MAX; index++)
    {
        writeData[index] = index;
    }

    while (1)
    {
        eReturnCode = C1_BSP_IPC_Write (&writeData[0], C1_BSP_IPC_MESSAGE_MAX);
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
            /* error */
            c1_ipc_msgCounterError_tx++;
        }
        else
        {
            c1_ipc_msgCounterOk_tx++;
        }

        DEVICE_DELAY_US(5000);
    }
    //while (1);
#endif

#if 0
	//uint32_t writeData[2] = {0x111, 0x101};
	//uint32_t writeDataLen = sizeof(writeData);

	static uint32_t okCounter = 0, errorCounter = 0;

	//messageSize = sizeof(message);

    // Initialize PIE and clear PIE registers. Disables CPU interrupts.
    //
    //Interrupt_initModule();

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    //
    //Interrupt_initVectorTable();

    // Clear any IPC flags if set already (todo: move it to C1_BSP_IPC_Init())
    //IPC_clearFlagLtoR (IPC_CPU1_L_CM_R, IPC_FLAG_ALL);

    // Synchronize both the cores. (todo: move it to C1_BSP_IPC_Init())
    //IPC_sync (IPC_CPU1_L_CM_R, IPC_FLAG31);

    // Enable Global Interrupt (INTM) and realtime interrupt (DBGM)
    //
    //EINT;
    //ERTM;

    while (0)
    {

        GPIO_writePin(DEVICE_GPIO_PIN_LED1, 0);
        DEVICE_DELAY_US(500000);

        GPIO_writePin(DEVICE_GPIO_PIN_LED1, 1);
        DEVICE_DELAY_US(500000);
    }


    while (1)
    {
        eReturnCode = C1_BSP_IPC_Write (writeData, 8, IPC_FLAG0);
        //eReturnCode = C1_BSP_IPC_Write ((uint32_t *) message,  messageSize, IPC_FLAG5);
        if (eReturnCode != BSP_RETURN_SUCCESS)
        {
            /* error */
            errorCounter++;
        }

        DEVICE_DELAY_US(500000);
    }
#endif
}
