
#include "C1_UUT_Main.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///  <GROUP $UUT_FUNCTIONS>
///  DESCRIPTION:
///		UUT Main initialization
///
///  PARAMETERS:
///    eTest - type of test
///d
///  RETURNS:
///    BSP_Return_E
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
BSP_Return_E C1_UUT_MAIN_Start (C1_UUT_MAIN_Test_Enum eTest)
{
	BSP_Return_E eReturnCode = BSP_RETURN_SUCCESS;

	switch (eTest)
	{
	    case C1_UUT_MAIN_TEST_IPC:
		    C1_UUT_IPC_Test ();
		    break;

	    case C1_UUT_MAIN_TEST_UART:
	        C1_UUT_UART_Test();
		    break;
			
        case C1_UUT_MAIN_TEST_TIMER:
            C1_UUT_TIMER_Test ();
            break;

        case C1_UUT_MAIN_TEST_GPIO:
            C1_UUT_GPIO_Test ();
            break;

		default:
			return BSP_RETURN_SWITCH_CASE_IS_INVALID;
	}

	return eReturnCode;
}
